<?php

namespace App\Http\Requests;

use App\Services\StoreContext;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        $storeId = app(StoreContext::class)->requireIdFor($this->user());

        return [
            // SKU dan barcode tidak dapat diubah (barcode tidak boleh dipakai ulang)
            'sku' => ['prohibited'],
            'barcode' => ['prohibited'],
            'name' => ['sometimes', 'required', 'string', 'max:200'],
            'supplier_ids' => ['sometimes', 'required', 'array', 'min:1', 'max:100'],
            'supplier_ids.*' => ['required', 'integer', 'distinct', Rule::exists('suppliers', 'id')->where('store_id', $storeId)],
            'category_id' => ['sometimes', 'nullable', 'integer', Rule::exists('categories', 'id')->where('store_id', $storeId)->where('is_active', 1)],
            'unit_name' => ['sometimes', 'required', 'string', 'max:20'],
            'track_expiry' => ['sometimes', 'required', 'boolean'],
            'sell_price' => ['sometimes', 'required', 'numeric', 'min:0', 'max:999999999999'],
            'unit_cost' => ['sometimes', 'required', 'numeric', 'min:0.0001', 'max:99999999999999', 'regex:/^\d+(?:\.\d{1,4})?$/'],
            'min_stock' => ['sometimes', 'required', 'numeric', 'min:0', 'max:999999999'],
            'critical_stock' => ['sometimes', 'required', 'numeric', 'min:0', 'max:999999999'],
            'restock_quantity' => ['sometimes', 'required', 'numeric', 'min:0', 'max:99999', 'regex:/^\d+(?:\.\d{1,3})?$/'],
            'status' => ['sometimes', 'required', Rule::in(['active', 'inactive'])],
            'reason' => ['nullable', 'string', 'max:500'],
        ];
    }
}
