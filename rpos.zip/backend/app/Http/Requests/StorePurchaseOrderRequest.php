<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StorePurchaseOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        return [
            'pr_id' => ['required', 'integer', 'min:1'],
            'supplier_id' => ['required', 'integer', 'min:1'],
            'bank_account_id' => ['required', 'integer', 'min:1'],
            'approver_user_id' => ['nullable', 'integer', 'min:1'],
            'approver_username' => ['nullable', 'string', 'max:60'],
            'approver_password' => ['nullable', 'string', 'max:200'],
            'approver_key' => ['nullable', 'string', 'max:200'],
            'payment_terms' => ['nullable', Rule::in(['top', 'cbd', 'cod'])],
            'payment_term_days' => ['nullable', 'integer', 'min:1', 'max:65535', 'required_if:payment_terms,top'],
            'order_date' => ['nullable', 'date_format:Y-m-d'],
            'expected_date' => ['nullable', 'date_format:Y-m-d'],
            'items' => ['required', 'array', 'min:1', 'max:100'],
            'items.*.product_id' => ['required', 'integer', 'min:1'],
            'items.*.qty_ordered' => ['required', 'numeric', 'gt:0', 'max:99999', 'decimal:0,3'],
            'items.*.unit_price' => ['required', 'numeric', 'min:0', 'max:99999999.99', 'decimal:0,2'],
        ];
    }
}
