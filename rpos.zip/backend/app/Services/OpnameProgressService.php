<?php

namespace App\Services;

use App\Exceptions\OpnameLookupException;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class OpnameProgressService
{
    public function __construct(private OpnameDisplayPolicy $displayPolicy) {}

    /** @return array<string, mixed>|null */
    public function tree(int $storeId, int $sessionId): ?array
    {
        $session = $this->session($storeId, $sessionId);
        if ($session === null) {
            return null;
        }

        $reveals = $this->displayPolicy->revealsSystemQty($storeId);
        $groups = $this->itemGroups($sessionId);
        $categories = DB::table('categories')->where('store_id', $storeId)->orderBy('name')->get(['id', 'parent_id', 'name']);
        $categoryById = $categories->keyBy('id');
        $children = [];
        foreach ($categories as $category) {
            $parentId = $category->parent_id === null ? 0 : (int) $category->parent_id;
            $children[$parentId][] = (int) $category->id;
        }

        $direct = [];
        $other = $this->emptyCounts();
        $staleCategoryIds = [];
        foreach ($groups as $group) {
            $categoryId = $group->category_id === null ? null : (int) $group->category_id;
            $category = $categoryId === null ? null : $categoryById->get($categoryId);
            $currentParentName = $category?->parent_id === null
                ? null
                : $categoryById->get((int) $category->parent_id)?->name;
            $isStale = $categoryId !== null && (
                $category === null
                || $category->name !== $group->category_name_snapshot
                || $currentParentName !== $group->category_parent_name_snapshot
            );
            $counts = $this->countsFromGroup($group);
            if ($isStale || $categoryId === null) {
                if ($categoryId !== null) {
                    $staleCategoryIds[$categoryId] = true;
                }
                $this->addCounts($other, $counts);
            } else {
                $direct[$categoryId] ??= $this->emptyCounts();
                $this->addCounts($direct[$categoryId], $counts);
            }
        }

        $build = function (int $parentId, int $depth = 0) use (&$build, $children, $categoryById, $direct, $reveals): array {
            $nodes = [];
            foreach ($children[$parentId] ?? [] as $categoryId) {
                $childNodes = $build($categoryId, $depth + 1);
                $directCounts = $direct[$categoryId] ?? $this->emptyCounts();
                $total = $directCounts;
                foreach ($childNodes as $child) {
                    $this->addCounts($total, [
                        'product_count' => $child['product_count'],
                        'counted_count' => $child['counted_count'],
                        'variance_count' => $child['variance_count'] ?? 0,
                    ]);
                }
                if ($total['product_count'] === 0) {
                    continue;
                }
                $category = $categoryById->get($categoryId);
                $node = [
                    'id' => $categoryId,
                    'name' => $category->name,
                    'parent_id' => $category->parent_id === null ? null : (int) $category->parent_id,
                    'depth' => $depth,
                    'product_count' => $total['product_count'],
                    'counted_count' => $total['counted_count'],
                    'status' => $this->nodeStatus($total['product_count'], $total['counted_count']),
                    'direct_product_count' => $directCounts['product_count'],
                    'direct_counted_count' => $directCounts['counted_count'],
                    'children' => $childNodes,
                ];
                if ($reveals) {
                    $node['variance_count'] = $total['variance_count'];
                }
                $nodes[] = $node;
            }

            return $nodes;
        };

        $nodes = $build(0);
        $total = $this->emptyCounts();
        foreach ($direct as $counts) {
            $this->addCounts($total, $counts);
        }
        $this->addCounts($total, $other);
        if ($other['product_count'] > 0) {
            $otherNode = [
                'id' => 'other',
                'name' => 'Lainnya',
                'parent_id' => null,
                'depth' => 0,
                'product_count' => $other['product_count'],
                'counted_count' => $other['counted_count'],
                'status' => $this->nodeStatus($other['product_count'], $other['counted_count']),
                'direct_product_count' => $other['product_count'],
                'direct_counted_count' => $other['counted_count'],
                'children' => [],
            ];
            if ($reveals) {
                $otherNode['variance_count'] = $other['variance_count'];
            }
            $nodes[] = $otherNode;
        }

        $tree = [
            'session' => [
                'id' => (int) $session->id,
                'number' => $session->number,
                'status' => $session->status,
                'condition_counting' => (bool) $session->condition_counting,
            ],
            'display' => ['reveals_system_qty' => $reveals],
            'summary' => [
                'total_products' => $total['product_count'],
                'counted_products' => $total['counted_count'],
            ],
            'nodes' => $nodes,
        ];

        return $tree;
    }

    /**
     * @param list<int> $productIds
     * @return array<int, list<array<string, mixed>>>
     */
    private function receiptSources(int $storeId, array $productIds): array
    {
        if ($productIds === []) {
            return [];
        }

        $rows = DB::table('inventory_balances as b')
            ->join('products as p', 'p.id', '=', 'b.product_id')
            ->leftJoin('product_batches as pb', 'pb.id', '=', 'b.batch_id')
            ->leftJoin('goods_receipt_items as gri', 'gri.id', '=', 'pb.goods_receipt_item_id')
            ->leftJoin('goods_receipts as gr', 'gr.id', '=', 'gri.gr_id')
            ->leftJoin('purchase_orders as po', 'po.id', '=', 'gr.po_id')
            ->where('p.store_id', $storeId)
            ->whereIn('b.product_id', $productIds)
            ->whereRaw('(b.qty_sellable + b.qty_quarantine + b.qty_damaged) > 0')
            ->groupBy('b.product_id', 'b.batch_id', 'po.doc_number', 'po.order_date', 'gr.doc_number', 'gr.posted_at')
            ->orderBy('b.product_id')->orderBy('po.order_date')->orderBy('gr.posted_at')
            ->select([
                'b.product_id',
                'b.batch_id',
                'po.doc_number as po_number',
                'po.order_date as po_date',
                'gr.doc_number as receipt_number',
                'gr.posted_at as receipt_date',
            ])
            ->selectRaw('SUM(b.qty_sellable) as good_qty')
            ->selectRaw('SUM(b.qty_damaged + b.qty_quarantine) as damaged_qty')
            ->get()
            ->map(fn (object $row) => [
                'product_id' => (int) $row->product_id,
                'batch_id' => $row->batch_id === null ? null : (int) $row->batch_id,
                'po_number' => $row->po_number,
                'po_date' => $row->po_date,
                'receipt_number' => $row->receipt_number,
                'receipt_date' => $row->receipt_date,
                'good_qty' => (string) $row->good_qty,
                'damaged_qty' => (string) $row->damaged_qty,
            ]);

        $sources = [];
        foreach ($rows as $row) {
            $productId = $row['product_id'];
            unset($row['product_id']);
            $sources[$productId][] = $row;
        }

        return $sources;
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function items(int $storeId, int $sessionId, array $filters, int $perPage): LengthAwarePaginator
    {
        $session = $this->session($storeId, $sessionId);
        abort_if($session === null, 404, 'Sesi opname tidak ditemukan.');
        $reveals = $this->displayPolicy->revealsSystemQty($storeId);
        $staleCategoryIds = $this->staleCategoryIds($sessionId, $storeId);
        $categoryMap = DB::table('categories')->where('store_id', $storeId)
            ->get(['id', 'parent_id', 'name'])->keyBy('id');
        $query = DB::table('stock_opname_items as i')
            ->where('i.session_id', $sessionId);

        if (array_key_exists('category_id', $filters)) {
            $categoryId = (int) $filters['category_id'];
            if ($categoryId === 0) {
                $query->where(function ($builder) use ($staleCategoryIds) {
                    $builder->whereNull('i.category_id');
                    if ($staleCategoryIds !== []) {
                        $builder->orWhereIn('i.category_id', $staleCategoryIds);
                    }
                });
            } else {
                $categoryIds = [$categoryId];
                if (($filters['scope'] ?? 'direct') === 'all') {
                    $categoryIds = $this->categoryDescendants($storeId, $categoryId);
                }
                $categoryIds = array_values(array_diff($categoryIds, $staleCategoryIds));
                $query->whereIn('i.category_id', $categoryIds === [] ? [-1] : $categoryIds);
            }
        }
        if (! empty($filters['q'])) {
            $term = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], (string) $filters['q']);
            $query->where(function ($builder) use ($term) {
                $builder->where('i.product_name_snapshot', 'like', "%{$term}%")
                    ->orWhere('i.barcode_snapshot', 'like', "{$term}%");
            });
        }
        if (! empty($filters['only_uncounted'])) {
            $query->whereNull('i.counted_qty');
        }
        if (! empty($filters['only_counted'])) {
            $query->whereNotNull('i.counted_qty');
        }
        if (! empty($filters['only_changes'])) {
            $query->where(function ($builder) {
                $builder->whereNotNull('i.reconciliation_action')
                    ->orWhere('i.diff_qty', '<>', 0)
                    ->orWhere('i.diff_good_qty', '<>', 0)
                    ->orWhere('i.diff_damaged_qty', '<>', 0);
            });
        }
        if (! empty($filters['exclude_item_ids'])) {
            $query->whereNotIn('i.id', array_map('intval', $filters['exclude_item_ids']));
        }
        if (! empty($filters['q'])) {
            $query->orderByRaw('CASE WHEN i.barcode_snapshot = ? THEN 0 ELSE 1 END', [(string) $filters['q']]);
        }

        $query = ($filters['sort'] ?? null) === '-counted_at'
            ? $query->orderByDesc('i.counted_at')->orderByDesc('i.id')
            : $query->orderBy('i.product_name_snapshot')->orderBy('i.id');

        $page = $query->paginate($perPage);
        $sourceMap = ! empty($filters['include_sources'])
            ? $this->receiptSources($storeId, $page->getCollection()->pluck('product_id')->map(fn ($id) => (int) $id)->all())
            : [];
        $showConditionQty = $reveals || in_array($session->status, ['pending_approval', 'posted'], true);

        return $page->through(function (object $item) use ($reveals, $showConditionQty, $staleCategoryIds, $categoryMap, $sourceMap, $filters) {
                $row = [
                    'id' => (int) $item->id,
                    'product_id' => (int) $item->product_id,
                    'category_id' => $item->category_id === null ? null : (int) $item->category_id,
                    'name' => $item->product_name_snapshot,
                    'sku' => $item->product_sku_snapshot,
                    'barcode' => $item->barcode_snapshot,
                    'category_path' => $this->categoryPath($item, $staleCategoryIds, $categoryMap),
                    'status' => $this->displayPolicy->itemStatus($item, $reveals),
                    'counted_qty' => $item->counted_qty,
                    'counted_good_qty' => $item->counted_good_qty,
                    'counted_damaged_qty' => $item->counted_damaged_qty,
                    'counted_at' => $item->counted_at,
                ];
                if ($reveals) {
                    $row['system_qty'] = $item->system_qty_at_count ?? $item->system_qty_at_start;
                }
                if ($showConditionQty) {
                    $row['system_good_qty'] = $item->system_good_qty_at_count;
                    $row['system_damaged_qty'] = $item->system_damaged_qty_at_count;
                }
                if ($showConditionQty && ($item->diff_good_qty !== null || $item->diff_damaged_qty !== null)) {
                    $row['diff_good_qty'] = $item->diff_good_qty;
                    $row['diff_damaged_qty'] = $item->diff_damaged_qty;
                }
                if ($showConditionQty) {
                    $row['diff_qty'] = $item->diff_qty;
                    if ($item->reconciliation_action !== null) {
                        $row['reconciliation_action'] = $item->reconciliation_action;
                        $row['reconciliation_reason'] = $item->reconciliation_reason;
                        $row['reconciliation_diff_qty'] = $item->reconciliation_diff_qty ?? $item->diff_qty;
                        $row['reconciliation_diff_good_qty'] = $item->reconciliation_diff_good_qty ?? $item->diff_good_qty;
                        $row['reconciliation_diff_damaged_qty'] = $item->reconciliation_diff_damaged_qty ?? $item->diff_damaged_qty;
                    }
                }
                if (! empty($filters['include_sources'])) {
                    $row['source_receipts'] = $sourceMap[(int) $item->product_id] ?? [];
                }

                return $row;
            });
    }

    /** @return array<string, mixed>|null */
    public function item(int $storeId, int $sessionId, int $itemId): ?array
    {
        if ($this->session($storeId, $sessionId) === null) {
            return null;
        }

        $item = DB::table('stock_opname_items')
            ->where('session_id', $sessionId)
            ->where('id', $itemId)
            ->first();

        return $item === null ? null : $this->presentItemRows($storeId, $sessionId, collect([$item]))[0];
    }

    /** @return list<array<string, mixed>> */
    public function lookup(int $storeId, int $sessionId, string $query, string $mode = 'auto'): array
    {
        abort_if($this->session($storeId, $sessionId) === null, 404, 'Sesi opname tidak ditemukan.');
        $query = trim($query);

        $exact = DB::table('stock_opname_items')
            ->where('session_id', $sessionId)
            ->whereRaw('LOWER(barcode_snapshot) = LOWER(?)', [$query])
            ->first();
        if ($exact !== null) {
            return $this->presentItemRows($storeId, $sessionId, collect([$exact]));
        }

        if ($mode !== 'search') {
            $product = DB::table('products')
                ->where('store_id', $storeId)
                ->whereRaw('LOWER(barcode) = LOWER(?)', [$query])
                ->first(['name']);
            if ($product !== null) {
                throw new OpnameLookupException(
                    'not_in_session',
                    "Produk {$product->name} tidak termasuk dalam sesi ini (produk baru dihitung di opname berikutnya).",
                    $product->name,
                );
            }

            if ($mode === 'barcode' || preg_match('/^[\pL\pN-]{8,}$/u', $query) === 1) {
                throw new OpnameLookupException('unknown_barcode', 'Barcode tidak dikenal.');
            }
        }

        if (mb_strlen($query) < 2) {
            return [];
        }

        $term = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $query);
        $items = DB::table('stock_opname_items')
            ->where('session_id', $sessionId)
            ->where('product_name_snapshot', 'like', "%{$term}%")
            ->orderBy('product_name_snapshot')
            ->limit(10)
            ->get();

        return $this->presentItemRows($storeId, $sessionId, $items);
    }

    /** @return array<string, mixed>|null */
    public function offlineIndex(int $storeId, int $sessionId, int $page, int $perPage): ?array
    {
        $session = $this->session($storeId, $sessionId);
        if ($session === null) {
            return null;
        }
        abort_if($session->status !== 'in_progress', 409, 'Sesi opname tidak sedang berjalan.');

        $total = DB::table('stock_opname_items')->where('session_id', $sessionId)->count();
        $totalPages = max(1, (int) ceil($total / $perPage));
        abort_if($page > $totalPages, 404, 'Halaman indeks opname tidak ditemukan.');
        $rows = DB::table('stock_opname_items')
            ->where('session_id', $sessionId)
            ->orderBy('id')
            ->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->get([
                'id', 'product_id', 'product_name_snapshot', 'product_sku_snapshot',
                'barcode_snapshot', 'category_id', 'counted_qty', 'counted_good_qty', 'counted_damaged_qty',
            ]);
        $latestItemUpdate = DB::table('stock_opname_items')->where('session_id', $sessionId)->max('updated_at');
        $latestLogId = DB::table('stock_opname_count_logs')->where('session_id', $sessionId)->max('id') ?? 0;
        $version = hash('sha256', implode('|', [
            $sessionId,
            $total,
            $latestItemUpdate ?? '',
            $latestLogId,
        ]));
        $categories = DB::table('categories')->where('store_id', $storeId)->orderBy('id')
            ->get(['id', 'name', 'parent_id'])
            ->map(fn (object $category) => [
                'id' => (int) $category->id,
                'name' => $category->name,
                'parent_id' => $category->parent_id === null ? null : (int) $category->parent_id,
            ])->all();

        return [
            'session' => [
                'id' => (int) $session->id,
                'number' => $session->number,
                'status' => $session->status,
                'condition_counting' => (bool) $session->condition_counting,
            ],
            'version' => $version,
            'categories' => $categories,
            'items' => $rows->map(fn (object $item) => [
                'item_id' => (int) $item->id,
                'product_id' => (int) $item->product_id,
                'name' => $item->product_name_snapshot,
                'sku' => $item->product_sku_snapshot,
                'barcode' => $item->barcode_snapshot,
                'category_id' => $item->category_id === null ? null : (int) $item->category_id,
                'counted_qty' => $item->counted_qty === null ? null : (int) $item->counted_qty,
                'counted_good_qty' => $item->counted_good_qty,
                'counted_damaged_qty' => $item->counted_damaged_qty,
            ])->all(),
            'page' => $page,
            'total_pages' => $totalPages,
            'total' => $total,
        ];
    }

    /** @param Collection<int, object> $items
     * @return list<array<string, mixed>>
     */
    private function presentItemRows(int $storeId, int $sessionId, Collection $items): array
    {
        $reveals = $this->displayPolicy->revealsSystemQty($storeId);
        $staleCategoryIds = $this->staleCategoryIds($sessionId, $storeId);
        $categoryMap = DB::table('categories')->where('store_id', $storeId)
            ->get(['id', 'parent_id', 'name'])->keyBy('id');

        return $items->map(function (object $item) use ($reveals, $staleCategoryIds, $categoryMap) {
            $presented = [
                'id' => (int) $item->id,
                'product_id' => (int) $item->product_id,
                'category_id' => $item->category_id === null ? null : (int) $item->category_id,
                'name' => $item->product_name_snapshot,
                'barcode' => $item->barcode_snapshot,
                'category_path' => $this->categoryPath($item, $staleCategoryIds, $categoryMap),
                'status' => $this->displayPolicy->itemStatus($item, $reveals),
                'counted_qty' => $item->counted_qty,
                'counted_good_qty' => $item->counted_good_qty,
                'counted_damaged_qty' => $item->counted_damaged_qty,
                'counted_at' => $item->counted_at,
            ];
            if ($reveals) {
                $presented['system_qty'] = $item->system_qty_at_count ?? $item->system_qty_at_start;
            }
            if ($reveals && ($item->system_good_qty_at_count !== null || $item->system_damaged_qty_at_count !== null)) {
                $presented['system_good_qty'] = $item->system_good_qty_at_count;
                $presented['system_damaged_qty'] = $item->system_damaged_qty_at_count;
                $presented['diff_good_qty'] = $item->diff_good_qty;
                $presented['diff_damaged_qty'] = $item->diff_damaged_qty;
            }

            return $presented;
        })->all();
    }

    /** @return list<object> */
    private function itemGroups(int $sessionId): array
    {
        return DB::table('stock_opname_items')
            ->where('session_id', $sessionId)
            ->groupBy('category_id', 'category_name_snapshot', 'category_parent_name_snapshot')
            ->selectRaw('category_id, category_name_snapshot, category_parent_name_snapshot')
            ->selectRaw('COUNT(*) as product_count')
            ->selectRaw('SUM(CASE WHEN counted_qty IS NOT NULL THEN 1 ELSE 0 END) as counted_count')
            ->selectRaw('SUM(CASE WHEN counted_qty IS NOT NULL AND (CASE WHEN diff_good_qty IS NOT NULL OR diff_damaged_qty IS NOT NULL THEN COALESCE(diff_good_qty, 0) <> 0 OR COALESCE(diff_damaged_qty, 0) <> 0 ELSE COALESCE(system_qty_at_count, system_qty_at_start) <> counted_qty END) THEN 1 ELSE 0 END) as variance_count')
            ->get()->all();
    }

    /** @return array{product_count: int, counted_count: int, variance_count: int} */
    private function emptyCounts(): array
    {
        return ['product_count' => 0, 'counted_count' => 0, 'variance_count' => 0];
    }

    /** @return array{product_count: int, counted_count: int, variance_count: int} */
    private function countsFromGroup(object $group): array
    {
        return [
            'product_count' => (int) $group->product_count,
            'counted_count' => (int) $group->counted_count,
            'variance_count' => (int) $group->variance_count,
        ];
    }

    /** @param array{product_count: int, counted_count: int, variance_count: int} $target
     * @param  array{product_count: int, counted_count: int, variance_count: int}  $source
     */
    private function addCounts(array &$target, array $source): void
    {
        $target['product_count'] += $source['product_count'];
        $target['counted_count'] += $source['counted_count'];
        $target['variance_count'] += $source['variance_count'];
    }

    private function nodeStatus(int $total, int $counted): string
    {
        if ($counted === 0) {
            return 'not_started';
        }

        return $counted === $total ? 'done' : 'partial';
    }

    private function session(int $storeId, int $sessionId): ?object
    {
        return DB::table('stock_opname_sessions')
            ->where('store_id', $storeId)->where('id', $sessionId)->first(['id', 'number', 'status', 'condition_counting']);
    }

    /** @return list<int> */
    private function staleCategoryIds(int $sessionId, int $storeId): array
    {
        $groups = $this->itemGroups($sessionId);
        $categoryIds = array_values(array_unique(array_filter(array_map(
            fn (object $group) => $group->category_id === null ? null : (int) $group->category_id,
            $groups,
        ))));
        if ($categoryIds === []) {
            return [];
        }

        $categories = DB::table('categories as c')
            ->leftJoin('categories as p', 'p.id', '=', 'c.parent_id')
            ->where('c.store_id', $storeId)->whereIn('c.id', $categoryIds)
            ->get(['c.id', 'c.name', 'p.name as parent_name'])->keyBy('id');
        $stale = [];
        foreach ($groups as $group) {
            if ($group->category_id === null) {
                continue;
            }
            $categoryId = (int) $group->category_id;
            $category = $categories->get($categoryId);
            if (
                $category === null
                || $category->name !== $group->category_name_snapshot
                || $category->parent_name !== $group->category_parent_name_snapshot
            ) {
                $stale[$categoryId] = true;
            }
        }

        return array_map('intval', array_keys($stale));
    }

    /** @return list<int> */
    private function categoryDescendants(int $storeId, int $categoryId): array
    {
        $categories = DB::table('categories')->where('store_id', $storeId)->get(['id', 'parent_id']);
        $children = [];
        foreach ($categories as $category) {
            $children[$category->parent_id === null ? 0 : (int) $category->parent_id][] = (int) $category->id;
        }

        $collect = function (int $id) use (&$collect, $children): array {
            $ids = [$id];
            foreach ($children[$id] ?? [] as $childId) {
                array_push($ids, ...$collect($childId));
            }

            return $ids;
        };

        return $collect($categoryId);
    }

    /** @param list<int> $staleCategoryIds @return list<string> */
    private function categoryPath(object $item, array $staleCategoryIds, Collection $categories): array
    {
        $categoryId = $item->category_id === null ? null : (int) $item->category_id;
        if ($categoryId === null || in_array($categoryId, $staleCategoryIds, true)) {
            return array_values(array_filter(array_unique([
                $item->category_parent_name_snapshot,
                $item->category_name_snapshot,
            ]), fn (?string $name) => $name !== null && $name !== ''));
        }

        $path = [];
        $cursor = $categoryId;
        while ($cursor !== null && isset($categories[$cursor])) {
            $category = $categories[$cursor];
            array_unshift($path, $category->name);
            $cursor = $category->parent_id === null ? null : (int) $category->parent_id;
        }

        return $path;
    }
}
