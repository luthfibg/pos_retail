<?php

namespace App\Services;

use App\Models\User;
use App\Support\Decimal;
use Carbon\Carbon;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Shift kasir (satu shift aktif per kasir dan per mesin/laci).
 *  - alur: open -> counting (penjualan baru diblokir) -> closed -> reviewed
 *  - saldo awal = endapan shift sebelumnya di laci yang sama (float_kept), 0 untuk shift pertama
 *  - kas diharapkan = saldo awal + penjualan tunai
 *  - hitung buta: selama shift berjalan, kas diharapkan hanya terlihat pemegang shift.review
 *  - selisih != 0 wajib berketerangan
 *  - saat tutup: endapan dan setoran akhir dihitung dari kebijakan endapan (CashDepositService); float_kept = endapan,
 *    dan dokumen setoran Draft dibuat bila ada yang disetor. Tanpa kebijakan aktif: float_kept = seluruh kas terhitung (tanpa setoran)
 *  - shift baru tidak dapat dibuka selama setoran akhir shift sebelumnya masih Draft (uangnya belum diserahkan)
 */
class ShiftService
{
    public function __construct(
        private AuditLogger $audit,
        private CashDepositService $deposits,
    ) {}

    /** @return array<string, mixed> */
    public function open(User $actor, int $storeId, ?string $addedOpeningCash, ?int $registerId): array
    {
        try {
            $id = DB::transaction(function () use ($actor, $storeId, $addedOpeningCash, $registerId) {
                DB::table('users')->where('id', $actor->id)->lockForUpdate()->first();
                $activeRegisters = DB::table('registers')->where('store_id', $storeId)->where('is_active', true);
                if ($registerId === null) {
                    $registerIds = $activeRegisters->orderBy('id')->pluck('id');
                    if ($registerIds->count() !== 1) {
                        throw ValidationException::withMessages([
                            'register_id' => [$registerIds->isEmpty()
                                ? 'Mesin kasir aktif belum tersedia.'
                                : 'Pilih mesin kasir yang akan digunakan untuk membuka shift.'],
                        ]);
                    }
                    $registerId = (int) $registerIds->first();
                }
                $register = DB::table('registers')->where('store_id', $storeId)->where('id', $registerId)
                    ->where('is_active', true)->lockForUpdate()->first();
                abort_if($register === null, 422, 'Kasir (register) aktif belum tersedia.');

                $existing = DB::table('cash_shifts as s')->join('users as u', 'u.id', '=', 's.cashier_id')
                    ->where('s.store_id', $storeId)->whereIn('s.status', ['open', 'counting'])
                    ->where(function ($q) use ($actor, $register) {
                        $q->where('s.cashier_id', $actor->id)->orWhere('s.register_id', $register->id);
                    })
                    ->first(['s.cashier_id', 's.register_id', 'u.name']);

                if ($existing !== null) {
                    $message = (int) $existing->cashier_id === $actor->id
                        ? 'Anda masih memiliki shift yang belum ditutup.'
                        : "Shift masih dibuka oleh {$existing->name}. Tutup dulu sebelum membuka shift baru.";
                    throw ValidationException::withMessages(['shift' => [$message]]);
                }

                $pendingDeposit = DB::table('cash_deposits as d')->join('cash_shifts as s', 's.id', '=', 'd.shift_id')
                    ->where('s.store_id', $storeId)->where('s.register_id', $register->id)->where('d.status', 'draft')->exists();
                if ($pendingDeposit) {
                    throw ValidationException::withMessages(['shift' => ['Setoran shift sebelumnya belum diserahkan. Serahkan setoran terlebih dahulu.']]);
                }

                $previous = DB::table('cash_shifts')
                    ->where('store_id', $storeId)->where('register_id', $register->id)->whereIn('status', ['closed', 'reviewed'])
                    ->orderByDesc('id')->first(['float_kept']);
                $previousFloat = Decimal::money((string) ($previous?->float_kept ?? '0.00'));
                $addition = Decimal::money($addedOpeningCash ?? '0');
                $opening = Decimal::moneyString($previousFloat + $addition);

                $number = $this->documentNumber($storeId, $actor);
                $openedAt = $this->now();

                $id = DB::table('cash_shifts')->insertGetId([
                    'store_id' => $storeId,
                    'doc_number' => $number,
                    'register_id' => $register->id,
                    'cashier_id' => $actor->id,
                    'opening_balance' => $opening,
                    'status' => 'open',
                    'opened_at' => $openedAt,
                ]);

                if ($addition > 0) {
                    $fundAccountId = DB::table('fund_accounts')
                        ->where('store_id', $storeId)
                        ->where('register_id', $register->id)
                        ->where('type', 'petty_cash')
                        ->where('is_active', true)
                        ->value('id');
                    abort_if($fundAccountId === null, 422, 'Akun Kas Kecil untuk mesin kasir belum tersedia.');

                    DB::table('fund_ledger_entries')->insert([
                        'fund_account_id' => $fundAccountId,
                        'entry_type' => 'shift_opening_addition',
                        'amount' => Decimal::moneyString($addition),
                        'ref_type' => 'cash_shift',
                        'ref_id' => $id,
                        'occurred_at' => $openedAt,
                        'created_by' => $actor->id,
                        'note' => 'Penambahan saldo saat buka kasir jaga',
                    ]);
                }

                $after = [
                    'doc_number' => $number,
                    'register_id' => (int) $register->id,
                    'register_name' => $register->name,
                    'opening_balance' => $opening,
                    'opening_balance_previous_float' => Decimal::moneyString($previousFloat),
                    'opening_balance_added' => Decimal::moneyString($addition),
                ];
                $this->audit->log('shift.open', 'shift', $id, after: $after, storeId: $storeId, actorId: $actor->id);

                return $id;
            });
        } catch (UniqueConstraintViolationException) {
            throw ValidationException::withMessages(['shift' => ['Shift pada kasir ini sudah dibuka.']]);
        }

        return $this->present($this->row($storeId, $id), $this->canSeeExpected($actor));
    }

    /** @return array<string, mixed>|null */
    public function current(User $actor, int $storeId): ?array
    {
        $row = DB::table('cash_shifts as s')
            ->join('users as u', 'u.id', '=', 's.cashier_id')
            ->join('registers as r', 'r.id', '=', 's.register_id')
            ->where('s.store_id', $storeId)->where('s.cashier_id', $actor->id)->whereIn('s.status', ['open', 'counting'])
            ->first(['s.*', 'u.name as cashier_name', 'u.cashier_number as cashier_number', 'r.name as register_name']);

        return $row === null ? null : $this->present($row, $this->canSeeExpected($actor));
    }

    /** Penjualan baru diblokir; kasir menghitung uang di laci. @return array<string, mixed> */
    public function startCount(User $actor, int $storeId, int $id, bool $canReview): array
    {
        DB::transaction(function () use ($actor, $storeId, $id, $canReview) {
            $shift = $this->lockOwned($actor, $storeId, $id, $canReview);

            if ($shift->status !== 'open') {
                throw ValidationException::withMessages(['status' => ['Shift tidak sedang dibuka.']]);
            }

            DB::table('cash_shifts')->where('id', $id)->update(['status' => 'counting']);
            $this->audit->log('shift.start_count', 'shift', $id, before: ['status' => 'open'], after: ['status' => 'counting'], storeId: $storeId, actorId: $actor->id);
        });

        return $this->present($this->row($storeId, $id), $this->canSeeExpected($actor));
    }

    /**
     * Tutup shift dengan kas fisik terhitung. Dari status open maupun counting.
     *
     * @return array<string, mixed>
     */
    public function close(User $actor, int $storeId, int $id, string $countedCash, ?string $note, bool $canReview): array
    {
        $floatFlags = [];

        DB::transaction(function () use ($actor, $storeId, $id, $countedCash, $note, $canReview, &$floatFlags) {
            $shift = $this->lockOwned($actor, $storeId, $id, $canReview);

            if (! in_array($shift->status, ['open', 'counting'], true)) {
                throw ValidationException::withMessages(['status' => ['Shift sudah ditutup.']]);
            }

            if (DB::table('cash_deposits')->where('shift_id', $id)->where('status', 'draft')->exists()) {
                throw ValidationException::withMessages(['status' => ['Masih ada setoran Draft pada shift ini. Serahkan atau batalkan dulu sebelum menutup shift.']]);
            }

            $summary = $this->summary($id, $shift->opening_balance);
            $counted = Decimal::money($countedCash);
            $variance = $counted - $summary['expected_units'];

            if ($variance !== 0 && ($note === null || trim($note) === '')) {
                throw ValidationException::withMessages(['variance_note' => ['Selisih kas wajib diberi keterangan.']]);
            }

            $plan = $this->deposits->plan($storeId, $id, $counted);

            DB::table('cash_shifts')->where('id', $id)->update([
                'status' => 'closed',
                'expected_cash' => Decimal::moneyString($summary['expected_units']),
                'counted_cash' => Decimal::moneyString($counted),
                'variance' => Decimal::moneyString($variance),
                'variance_note' => $variance === 0 ? null : $note,
                'float_kept' => Decimal::moneyString($plan['float']),
                'closed_at' => $this->now(),
            ]);

            $depositId = $this->deposits->createDraft($actor, $storeId, $shift, $counted, $plan);
            $floatFlags = $plan['flags'];

            $this->audit->log(
                'shift.close',
                'shift',
                $id,
                before: ['status' => $shift->status],
                after: [
                    'expected_cash' => Decimal::moneyString($summary['expected_units']),
                    'counted_cash' => Decimal::moneyString($counted),
                    'variance' => Decimal::moneyString($variance),
                    'float_kept' => Decimal::moneyString($plan['float']),
                    'deposit_amount' => Decimal::moneyString($plan['deposit']),
                ],
                reason: $variance === 0 ? null : $note,
                storeId: $storeId,
                actorId: $actor->id,
            );
        });

        return $this->present($this->row($storeId, $id), $this->canSeeExpected($actor)) + ['float_flags' => $floatFlags];
    }

    /** @return array<string, mixed> */
    public function review(User $actor, int $storeId, int $id, ?string $note): array
    {
        DB::transaction(function () use ($actor, $storeId, $id, $note) {
            $shift = DB::table('cash_shifts')->where('store_id', $storeId)->where('id', $id)->lockForUpdate()->first();
            abort_if($shift === null, 404, 'Shift tidak ditemukan.');

            if ($shift->status !== 'closed') {
                throw ValidationException::withMessages(['status' => ['Hanya shift yang sudah ditutup yang dapat ditinjau.']]);
            }

            DB::table('cash_shifts')->where('id', $id)->update([
                'status' => 'reviewed', 'reviewed_by' => $actor->id, 'reviewed_at' => $this->now(),
            ]);

            $this->audit->log(
                'shift.review', 'shift', $id,
                before: ['status' => 'closed'], after: ['status' => 'reviewed', 'variance' => $shift->variance],
                reason: $note, storeId: $storeId, actorId: $actor->id,
            );
        });

        return $this->present($this->row($storeId, $id), true);
    }

    /** @return array<string, mixed>|null */
    public function find(User $actor, int $storeId, int $id, bool $canReview): ?array
    {
        $row = $this->row($storeId, $id);

        if ($row === null || (! $canReview && (int) $row->cashier_id !== $actor->id)) {
            return null;
        }

        return $this->present($row, $canReview);
    }

    /** @param array<string, mixed> $filters */
    public function search(int $storeId, array $filters, int $perPage): LengthAwarePaginator
    {
        $query = DB::table('cash_shifts as s')
            ->join('users as u', 'u.id', '=', 's.cashier_id')
            ->join('registers as r', 'r.id', '=', 's.register_id')
            ->where('s.store_id', $storeId)
            ->orderByDesc('s.id')
            ->select(['s.*', 'u.name as cashier_name', 'u.cashier_number as cashier_number', 'r.name as register_name']);

        if (! empty($filters['status'])) {
            $query->where('s.status', $filters['status']);
        }
        if (! empty($filters['cashier_id'])) {
            $query->where('s.cashier_id', (int) $filters['cashier_id']);
        }
        if (! empty($filters['date_from'])) {
            $query->where('s.opened_at', '>=', Carbon::parse($filters['date_from'], 'Asia/Jakarta')->startOfDay()->utc());
        }
        if (! empty($filters['date_to'])) {
            $query->where('s.opened_at', '<=', Carbon::parse($filters['date_to'], 'Asia/Jakarta')->endOfDay()->utc());
        }

        return $query->paginate($perPage)->through(fn ($row) => $this->present($row, true));
    }

    /**
     * Ringkasan shift. expected_units dalam satuan sen.
     *
     * @return array{cash_sales_count: int, cash_sales_total: string, credit_sales_count: int, credit_sales_total: string, expected_units: int}
     */
    public function summary(int $shiftId, string $openingBalance): array
    {
        $sales = DB::table('sales')->where('shift_id', $shiftId)
            ->selectRaw('payment_mode, count(*) as c, coalesce(sum(total), 0) as t')->groupBy('payment_mode')->get()->keyBy('payment_mode');
        $cash = Decimal::money((string) ($sales['cash']->t ?? '0'));

        return [
            'cash_sales_count' => (int) ($sales['cash']->c ?? 0),
            'cash_sales_total' => Decimal::moneyString($cash),
            'credit_sales_count' => (int) ($sales['payroll_credit']->c ?? 0),
            'credit_sales_total' => Decimal::moneyString(Decimal::money((string) ($sales['payroll_credit']->t ?? '0'))),
            'expected_units' => Decimal::money($openingBalance) + $cash,
        ];
    }

    // ------------------------------------------------------------------ internal

    private function lockOwned(User $actor, int $storeId, int $id, bool $canReview): object
    {
        $shift = DB::table('cash_shifts')->where('store_id', $storeId)->where('id', $id)->lockForUpdate()->first();
        abort_if($shift === null, 404, 'Shift tidak ditemukan.');
        abort_if(! $canReview && (int) $shift->cashier_id !== $actor->id, 403, 'Anda hanya dapat mengelola shift sendiri.');

        return $shift;
    }

    private function row(int $storeId, int $id): ?object
    {
        return DB::table('cash_shifts as s')
            ->join('users as u', 'u.id', '=', 's.cashier_id')
            ->join('registers as r', 'r.id', '=', 's.register_id')
            ->where('s.store_id', $storeId)->where('s.id', $id)
            ->first(['s.*', 'u.name as cashier_name', 'u.cashier_number as cashier_number', 'r.name as register_name']);
    }

    private function canSeeExpected(User $user): bool
    {
        return $user->can('shift.review');
    }

    /** @return array<string, mixed> */
    private function present(object $row, bool $seeExpected): array
    {
        $summary = $this->summary((int) $row->id, $row->opening_balance);
        $finished = in_array($row->status, ['closed', 'reviewed'], true);

        $out = [
            'id' => (int) $row->id,
            'doc_number' => $row->doc_number,
            'register_id' => (int) $row->register_id,
            'register_name' => $row->register_name,
            'cashier_id' => (int) $row->cashier_id,
            'cashier_name' => $row->cashier_name,
            'cashier_number' => $row->cashier_number,
            'status' => $row->status,
            'opening_balance' => $row->opening_balance,
            'opened_at' => $row->opened_at,
            'closed_at' => $row->closed_at,
            'summary' => [
                'cash_sales_count' => $summary['cash_sales_count'],
                'cash_sales_total' => $summary['cash_sales_total'],
                'credit_sales_count' => $summary['credit_sales_count'],
                'credit_sales_total' => $summary['credit_sales_total'],
            ],
            'deposit' => $this->deposits->finalForShift((int) $row->id),
            'counted_cash' => $row->counted_cash,
            'variance' => $finished || $seeExpected ? $row->variance : null,
            'variance_note' => $row->variance_note,
            'float_kept' => $row->float_kept,
            'reviewed_at' => $row->reviewed_at,
        ];

        // hitung buta: kas diharapkan baru terlihat Kasir setelah shift ditutup
        $out['expected_cash'] = $finished
            ? $row->expected_cash
            : ($seeExpected ? Decimal::moneyString($summary['expected_units']) : null);

        return $out;
    }

    private function now(): string
    {
        return Carbon::now('UTC')->format('Y-m-d H:i:s.v');
    }

    private function documentNumber(int $storeId, User $cashier): string
    {
        $date = Carbon::now('Asia/Jakarta')->format('dmY');
        $name = Str::substr(Str::slug($cashier->name), 0, 150) ?: "kasir-{$cashier->id}";
        $base = "KASIR-JAGA-{$date}-{$name}";
        $candidate = $base;
        $suffix = 2;

        while (DB::table('cash_shifts')->where('store_id', $storeId)->where('doc_number', $candidate)->exists()) {
            $candidate = "{$base}-{$suffix}";
            $suffix++;
        }

        return $candidate;
    }
}
