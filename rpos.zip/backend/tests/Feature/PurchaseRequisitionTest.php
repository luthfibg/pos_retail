<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\PermissionResolver;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\Concerns\BuildsPurchasing;
use Tests\SeededTestCase;

class PurchaseRequisitionTest extends SeededTestCase
{
    use BuildsPurchasing;

    private User $cashier;

    private User $purchaser;

    protected function setUp(): void
    {
        parent::setUp();

        $this->cashier = $this->makeUser('Kasir', 'kasir-beli');
        $this->purchaser = $this->makeUser('Purchasing', 'purchasing-beli');
        Sanctum::actingAs($this->cashier, ['*']);
    }

    /** @return array<string, mixed> */
    private function payload(int $productId, array $item = []): array
    {
        return ['reason' => 'Stok menipis', 'items' => [$item + ['product_id' => $productId, 'qty' => '10', 'est_price' => '2500']]];
    }

    private function createSubmitted(int $productId): int
    {
        Sanctum::actingAs($this->purchaser, ['*']);
        $id = $this->postJson('/api/purchase-requisitions', $this->payload($productId))->assertCreated()->json('data.id');
        $this->postJson("/api/purchase-requisitions/{$id}/submit")->assertOk();

        return $id;
    }

    public function test_purchasing_creates_manual_draft_with_computed_total_number_and_audit(): void
    {
        $p1 = $this->product();
        $p2 = $this->product();

        Sanctum::actingAs($this->purchaser, ['*']);
        $response = $this->postJson('/api/purchase-requisitions', ['reason' => 'Stok menipis', 'items' => [
            ['product_id' => $p1, 'qty' => '10', 'est_price' => '2500'],
            ['product_id' => $p2, 'qty' => '2.5', 'est_price' => '1000.50', 'note' => 'merk bebas'],
        ]])->assertCreated()
            ->assertJsonPath('data.status', 'draft')
            ->assertJsonPath('data.est_total', '27501.25')   // 10 x 2500 + 2,5 x 1000,50
            ->assertJsonPath('data.items.0.qty', '10.000')
            ->assertJsonMissingPath('data.items.0.qty_ordered')
            ->assertJsonMissingPath('data.items.0.qty_remaining')
            ->assertJsonPath('data.requester_name', $this->purchaser->name)
            ->assertJsonPath('data.is_auto_generated', false);

        $this->assertMatchesRegularExpression('/^PR-\d{6}-000001$/', $response->json('data.doc_number'));
        $this->assertDatabaseHas('audit_logs', ['action' => 'purchase_requisition.create', 'actor_id' => $this->purchaser->id]);
    }

    public function test_cashier_cannot_create_manual_requisition(): void
    {
        $this->postJson('/api/purchase-requisitions', $this->payload($this->product()))
            ->assertForbidden();

        $this->assertSame(0, DB::table('purchase_requisitions')->count());
    }

    public function test_item_validation(): void
    {
        $good = $this->product();
        $inactive = $this->product(['status' => 'inactive']);
        Sanctum::actingAs($this->purchaser, ['*']);

        $this->postJson('/api/purchase-requisitions', ['items' => [['product_id' => $inactive, 'qty' => '1']]])
            ->assertUnprocessable()->assertJsonValidationErrors(['items.0.product_id']);
        $this->postJson('/api/purchase-requisitions', ['items' => [
            ['product_id' => $good, 'qty' => '1'], ['product_id' => $good, 'qty' => '2'],
        ]])->assertUnprocessable()->assertJsonValidationErrors(['items.1.product_id']);
        $this->postJson('/api/purchase-requisitions', ['items' => [['product_id' => 999999, 'qty' => '1']]])
            ->assertUnprocessable()->assertJsonValidationErrors(['items.0.product_id']);
        $this->postJson('/api/purchase-requisitions', $this->payload($good, ['qty' => '0']))
            ->assertUnprocessable()->assertJsonValidationErrors(['items.0.qty']);
        $this->postJson('/api/purchase-requisitions', ['items' => []])
            ->assertUnprocessable()->assertJsonValidationErrors(['items']);

        $this->assertSame(0, DB::table('purchase_requisitions')->count());
    }

    public function test_submit_notifies_finance_and_locks_editing(): void
    {
        $id = $this->createSubmitted($this->product());

        $this->assertSame(1, $this->notificationCount('pr.submitted', $this->seededAdmin()->id));
        Sanctum::actingAs($this->purchaser, ['*']);
        $this->patchJson("/api/purchase-requisitions/{$id}", ['reason' => 'ubah'])
            ->assertUnprocessable()->assertJsonValidationErrors(['status']);
    }

    public function test_finance_pass_makes_pr_ready_for_po_without_separate_owner_approval(): void
    {
        $id = $this->createSubmitted($this->product());

        $admin = $this->actAsAdmin();
        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'pass'])
            ->assertOk()->assertJsonPath('data.status', 'approved')
            ->assertJsonCount(1, 'data.approvals')
            ->assertJsonPath('data.approvals.0.step', 'finance_check')
            ->assertJsonMissingPath('data.approvals.1');

        $this->assertSame('approved', DB::table('purchase_requisitions')->where('id', $id)->value('status'));
        $this->assertSame(1, $this->notificationCount('pr.finance_checked', $this->purchaser->id));
        $this->assertDatabaseHas('audit_logs', ['action' => 'purchase_requisition.finance_check', 'actor_id' => $admin->id]);
    }

    public function test_finance_return_needs_note_and_allows_edit_and_resubmit(): void
    {
        $id = $this->createSubmitted($this->product());

        $this->actAsAdmin();
        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'return'])
            ->assertUnprocessable()->assertJsonValidationErrors(['note']);
        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'return', 'note' => 'Jumlah terlalu besar'])
            ->assertOk()->assertJsonPath('data.status', 'returned');
        $this->assertSame(1, $this->notificationCount('pr.returned', $this->purchaser->id));

        Sanctum::actingAs($this->purchaser, ['*']);
        $this->patchJson("/api/purchase-requisitions/{$id}", ['reason' => 'Sudah dikurangi'])->assertOk();
        $this->postJson("/api/purchase-requisitions/{$id}/submit")->assertOk()->assertJsonPath('data.status', 'submitted');
    }

    public function test_finance_check_requires_permission_and_owner_approval_is_not_a_pr_step(): void
    {
        $id = $this->createSubmitted($this->product());

        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'pass'])->assertForbidden();
        $this->postJson("/api/purchase-requisitions/{$id}/approve", $this->adminCreds())->assertForbidden();

        $this->actAsAdmin();
        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'pass'])->assertOk()
            ->assertJsonPath('data.status', 'approved');
        $this->postJson("/api/purchase-requisitions/{$id}/approve", $this->adminCreds())
            ->assertUnprocessable()->assertJsonValidationErrors(['status']);
        $this->assertSame('approved', DB::table('purchase_requisitions')->where('id', $id)->value('status'));
    }

    public function test_finance_return_requires_note(): void
    {
        $id = $this->createSubmitted($this->product());

        $this->actAsAdmin();
        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'return'])
            ->assertUnprocessable()->assertJsonValidationErrors(['note']);
        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'return', 'note' => 'Jumlah terlalu besar'])
            ->assertOk()->assertJsonPath('data.status', 'returned');

        $this->assertSame(1, $this->notificationCount('pr.returned', $this->purchaser->id));
    }

    public function test_finance_can_approve_pr_even_when_requester_is_an_admin(): void
    {
        $p = $this->product();
        $this->actAsAdmin();

        $first = $this->postJson('/api/purchase-requisitions', $this->payload($p))->assertCreated()->json('data.id');
        $this->postJson("/api/purchase-requisitions/{$first}/submit")->assertOk();
        $this->postJson("/api/purchase-requisitions/{$first}/finance-check", ['decision' => 'pass'])->assertOk();
        $this->setSetting('sod_owner_self_approve', 'block');

        $second = $this->postJson('/api/purchase-requisitions', $this->payload($p))->assertCreated()->json('data.id');
        $this->postJson("/api/purchase-requisitions/{$second}/submit")->assertOk();
        $this->postJson("/api/purchase-requisitions/{$second}/finance-check", ['decision' => 'pass'])->assertOk()
            ->assertJsonPath('data.status', 'approved');
        $this->assertSame('approved', DB::table('purchase_requisitions')->where('id', $second)->value('status'));
    }

    public function test_finance_pass_is_independent_of_owner_reauthentication_setting(): void
    {
        $id = $this->createSubmitted($this->product());
        $this->setSetting('approval_reauth_required', false);

        $this->actAsAdmin();
        $this->postJson("/api/purchase-requisitions/{$id}/finance-check", ['decision' => 'pass'])
            ->assertOk()->assertJsonPath('data.status', 'approved');
        $this->assertSame(1, DB::table('pr_approvals')->where('pr_id', $id)->count());
    }

    public function test_cancel_rules(): void
    {
        $p = $this->product();
        Sanctum::actingAs($this->purchaser, ['*']);
        $draft = $this->postJson('/api/purchase-requisitions', $this->payload($p))->assertCreated()->json('data.id');

        $other = $this->makeUser('Kasir', 'kasir-lain');
        Sanctum::actingAs($other, ['*']);
        $this->postJson("/api/purchase-requisitions/{$draft}/cancel")->assertForbidden();

        Sanctum::actingAs($this->purchaser, ['*']);
        $this->postJson("/api/purchase-requisitions/{$draft}/cancel", ['reason' => 'salah input'])
            ->assertOk()->assertJsonPath('data.status', 'cancelled');

        $approved = $this->pr($this->cashier->id, [$p => ['5', '1000']], 'approved');
        $this->actAsAdmin();
        $this->postJson("/api/purchase-requisitions/{$approved}/cancel")
            ->assertUnprocessable()->assertJsonValidationErrors(['status']);
    }

    public function test_visibility_cashier_sees_only_own_admin_sees_all(): void
    {
        $p = $this->product();
        $mine = $this->pr($this->cashier->id, [$p => ['1', null]], 'draft');
        $other = $this->makeUser('Kasir', 'kasir-lain');
        $theirs = $this->pr($other->id, [$p => ['1', null]], 'draft');

        $this->getJson('/api/purchase-requisitions')->assertOk()->assertJsonPath('total', 1)->assertJsonPath('data.0.id', $mine);
        $this->getJson("/api/purchase-requisitions/{$theirs}")->assertNotFound();

        $this->actAsAdmin();
        $this->getJson('/api/purchase-requisitions')->assertOk()->assertJsonPath('total', 2);
        $this->getJson('/api/purchase-requisitions?mine=1')->assertOk()->assertJsonPath('total', 0);
        $this->getJson("/api/purchase-requisitions/{$theirs}")->assertOk()->assertJsonPath('data.id', $theirs);
    }

    public function test_finance_permission_can_view_all_requisitions_without_create_permission(): void
    {
        $p = $this->product();
        $first = $this->pr($this->cashier->id, [$p => ['1', null]], 'submitted');
        $other = $this->makeUser('Kasir', 'kasir-finance-test');
        $second = $this->pr($other->id, [$p => ['2', null]], 'submitted');
        $permissionIds = DB::table('permissions')->whereIn('code', [
            'purchase_requisition.create',
            'purchase_requisition.finance_check',
        ])->pluck('id', 'code');
        $roleId = (int) DB::table('user_roles')->where('user_id', $this->cashier->id)->value('role_id');
        DB::table('role_permissions')->where('role_id', $roleId)->where('permission_id', $permissionIds['purchase_requisition.create'])->delete();
        DB::table('role_permissions')->insert([
            'role_id' => $roleId,
            'permission_id' => $permissionIds['purchase_requisition.finance_check'],
        ]);
        app(PermissionResolver::class)->flush();

        $this->getJson('/api/purchase-requisitions')
            ->assertOk()
            ->assertJsonPath('total', 2);
        $this->getJson("/api/purchase-requisitions/{$second}")
            ->assertOk()
            ->assertJsonPath('data.id', $second);
        $this->getJson("/api/purchase-requisitions/{$first}")
            ->assertOk()
            ->assertJsonPath('data.id', $first);
    }
}
