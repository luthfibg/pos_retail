<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\PermissionResolver;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Laravel\Sanctum\Sanctum;
use Tests\SeededTestCase;

class BillingTest extends SeededTestCase
{
    private User $admin;

    private User $cashier;

    private int $shiftId;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = $this->makeUser('Admin', 'admin-tagihan');
        $this->cashier = $this->makeUser('Kasir', 'kasir-tagihan');
        $this->shiftId = DB::table('cash_shifts')->insertGetId([
            'store_id' => $this->storeId(), 'doc_number' => 'SHIFT-TGH', 'register_id' => DB::table('registers')->value('id'),
            'cashier_id' => $this->cashier->id, 'opening_balance' => 0, 'status' => 'open', 'opened_at' => now(),
        ]);
        Sanctum::actingAs($this->admin, ['*']);
    }

    private function employee(string $no, string $name): int
    {
        return DB::table('customers')->insertGetId([
            'store_id' => $this->storeId(), 'customer_no' => $no, 'name' => $name, 'department' => 'Produksi',
            'created_by' => $this->admin->id,
        ]);
    }

    private function sale(?int $customerId, string $total, string $mode = 'payroll_credit', ?int $period = null): int
    {
        return DB::table('sales')->insertGetId([
            'store_id' => $this->storeId(), 'doc_number' => 'S-'.Str::random(8), 'shift_id' => $this->shiftId, 'cashier_id' => $this->cashier->id,
            'customer_id' => $customerId, 'payment_mode' => $mode, 'subtotal' => $total, 'total' => $total,
            'billing_status' => $mode === 'payroll_credit' ? 'unbilled' : 'not_applicable', 'billing_period_id' => $period,
            'idempotency_key' => (string) Str::uuid(), 'posted_at' => now()->subSecond(),
        ]);
    }

    private function openPeriod(): int
    {
        return $this->postJson('/api/billing-periods', ['label' => 'Oktober 2026', 'scheduled_close_date' => '2026-10-28'])
            ->assertCreated()->assertJsonPath('data.status', 'open')->json('data.id');
    }

    /** Dua karyawan dan tiga struk kredit, periode ditutup. @return array{int, int, int} [periode, budi, sari] */
    private function closedPeriodWithSales(): array
    {
        $budi = $this->employee('NIK-1', 'Budi');
        $sari = $this->employee('NIK-2', 'Sari');
        $period = $this->openPeriod();

        $this->sale($budi, '100000.00');
        $this->sale($budi, '50000.50');
        $this->sale($sari, '25000.00');
        $this->sale(null, '999000.00', 'cash');

        $this->postJson("/api/billing-periods/{$period}/close")->assertOk();

        return [$period, $budi, $sari];
    }

    public function test_open_period_once_and_update_schedule(): void
    {
        $this->getJson('/api/billing-periods/current')->assertOk()->assertJsonPath('data', null);

        $id = $this->openPeriod();
        $this->assertDatabaseHas('audit_logs', ['action' => 'billing_period.open', 'entity_id' => $id, 'actor_id' => $this->admin->id]);

        $this->postJson('/api/billing-periods', [])->assertUnprocessable()->assertJsonValidationErrors(['status']);
        $this->getJson('/api/billing-periods/current')->assertOk()->assertJsonPath('data.id', $id);

        $this->patchJson("/api/billing-periods/{$id}", ['scheduled_close_date' => '2026-10-30'])->assertOk()
            ->assertJsonPath('data.scheduled_close_date', '2026-10-30');
        $this->assertDatabaseHas('audit_logs', ['action' => 'billing_period.update', 'entity_id' => $id]);

        $this->patchJson("/api/billing-periods/{$id}", ['scheduled_close_date' => '30-10-2026'])->assertUnprocessable();
        $this->getJson('/api/billing-periods/99999')->assertNotFound();
    }

    public function test_annual_receivable_report_allocates_payments_and_keeps_closed_year_values_at_year_end(): void
    {
        $currentYear = Carbon::now('Asia/Jakarta')->year;
        $closedYear = $currentYear - 1;
        $currentDate = Carbon::create($currentYear, 1, 1, 10, 0, 0, 'Asia/Jakarta');
        Carbon::setTestNow(Carbon::create($closedYear, 12, 20, 10, 0, 0, 'Asia/Jakarta'));

        try {
            $budi = $this->employee('NIK-ANNUAL-1', 'Budi Annual');
            $sari = $this->employee('NIK-ANNUAL-2', 'Sari Annual');
            $period = $this->openPeriod();
            $this->sale($budi, '100.00');
            $this->sale($sari, '50.00');
            $this->postJson("/api/billing-periods/{$period}/close")->assertOk();
            $invoice = $this->postJson("/api/billing-periods/{$period}/invoice")->assertCreated()->json('data');
            DB::table('receivable_invoices')->where('id', $invoice['id'])->update([
                'tax_amount' => '15.00',
                'total' => '165.00',
                'created_at' => Carbon::create($closedYear, 12, 21, 10, 0, 0, 'Asia/Jakarta')->utc()->format('Y-m-d H:i:s.v'),
            ]);

            DB::table('invoice_payments')->insert([
                [
                    'invoice_id' => $invoice['id'], 'amount' => '75.00',
                    'received_at' => Carbon::create($closedYear, 12, 25, 12, 0, 0, 'Asia/Jakarta')->utc()->format('Y-m-d H:i:s.v'),
                    'recorded_by' => $this->admin->id,
                ],
                [
                    'invoice_id' => $invoice['id'], 'amount' => '25.00',
                    'received_at' => Carbon::create($currentYear, 1, 2, 12, 0, 0, 'Asia/Jakarta')->utc()->format('Y-m-d H:i:s.v'),
                    'recorded_by' => $this->admin->id,
                ],
            ]);

            Carbon::setTestNow($currentDate);
            $this->getJson('/api/annual-receivable-reports')
                ->assertOk()
                ->assertJsonPath('data.current_year', $currentYear)
                ->assertJsonPath('data.years.0.year', $currentYear)
                ->assertJsonPath('data.years.0.print_enabled', false)
                ->assertJsonPath('data.years.1.year', $closedYear)
                ->assertJsonPath('data.years.1.print_enabled', true);

            $this->getJson("/api/annual-receivable-reports/{$closedYear}")
                ->assertOk()
                ->assertJsonPath('data.totals.billed', '165.00')
                ->assertJsonPath('data.totals.paid', '75.00')
                ->assertJsonPath('data.totals.outstanding', '90.00')
                ->assertJsonPath('data.customers.0.customer_id', $budi)
                ->assertJsonPath('data.customers.0.billed', '110.00')
                ->assertJsonPath('data.customers.0.paid', '50.00')
                ->assertJsonPath('data.customers.0.outstanding', '60.00')
                ->assertJsonPath('data.customers.1.customer_id', $sari)
                ->assertJsonPath('data.customers.1.billed', '55.00')
                ->assertJsonPath('data.customers.1.paid', '25.00')
                ->assertJsonPath('data.customers.1.outstanding', '30.00');

            $this->getJson('/api/annual-receivable-reports/'.($currentYear + 1))->assertNotFound();
        } finally {
            Carbon::setTestNow();
        }
    }

    public function test_annual_receivable_print_setting_defaults_validates_and_audits_changes(): void
    {
        $this->getJson('/api/settings/annual-receivable-report')->assertOk()
            ->assertJsonPath('data.print_on', '12-31');

        $this->putJson('/api/settings/annual-receivable-report', ['print_on' => '02-30'])
            ->assertUnprocessable()->assertJsonValidationErrors(['print_on']);
        $this->putJson('/api/settings/annual-receivable-report', ['print_on' => '04-15'])
            ->assertOk()->assertJsonPath('data.print_on', '04-15');

        $this->assertDatabaseHas('settings', [
            'store_id' => $this->storeId(),
            'setting_key' => 'receivable_annual_report_print_on',
            'updated_by' => $this->admin->id,
        ]);
        $this->assertDatabaseHas('audit_logs', [
            'action' => 'settings.annual_receivable_report',
            'actor_id' => $this->admin->id,
        ]);

        $year = Carbon::now('Asia/Jakarta')->year;
        Carbon::setTestNow(Carbon::create($year, 4, 14, 12, 0, 0, 'Asia/Jakarta'));
        try {
            $this->getJson('/api/annual-receivable-reports')
                ->assertJsonPath('data.years.0.print_enabled', false);
            Carbon::setTestNow(Carbon::create($year, 4, 15, 12, 0, 0, 'Asia/Jakarta'));
            $this->getJson('/api/annual-receivable-reports')
                ->assertJsonPath('data.years.0.print_enabled', true);
        } finally {
            Carbon::setTestNow();
        }

        Sanctum::actingAs($this->cashier, ['*']);
        $this->getJson('/api/annual-receivable-reports')->assertForbidden();
        $this->getJson('/api/settings/annual-receivable-report')->assertForbidden();
    }

    public function test_annual_report_proportional_payment_rounding_does_not_overpay_a_customer(): void
    {
        $customers = [
            $this->employee('NIK-ANNUAL-A', 'Annual A'),
            $this->employee('NIK-ANNUAL-B', 'Annual B'),
            $this->employee('NIK-ANNUAL-C', 'Annual C'),
        ];
        $period = $this->openPeriod();
        foreach ($customers as $customerId) {
            $this->sale($customerId, '1.00');
        }
        $this->postJson("/api/billing-periods/{$period}/close")->assertOk();
        $invoice = $this->postJson("/api/billing-periods/{$period}/invoice")->assertCreated()->json('data');
        DB::table('invoice_payments')->insert([
            'invoice_id' => $invoice['id'],
            'amount' => '0.02',
            'received_at' => now('UTC')->format('Y-m-d H:i:s.v'),
            'recorded_by' => $this->admin->id,
        ]);
        $report = $this->getJson('/api/annual-receivable-reports/'.Carbon::now('Asia/Jakarta')->year)
            ->assertOk()
            ->assertJsonPath('data.totals.paid', '0.02')
            ->json('data');

        $this->assertSame(['0.01', '0.01', '0.00'], array_column($report['customers'], 'paid'));
        $this->assertSame(['0.99', '0.99', '1.00'], array_column($report['customers'], 'outstanding'));
    }

    public function test_default_period_label_uses_month_and_automatically_advances_to_next_month(): void
    {
        Carbon::setTestNow(Carbon::parse('2026-10-15 09:00:00', 'Asia/Jakarta'));

        try {
            $period = $this->postJson('/api/billing-periods', [])->assertCreated()
                ->assertJsonPath('data.label', 'Periode Oktober')
                ->assertJsonPath('data.period_month', '2026-10-01')
                ->json('data.id');

            $this->patchJson("/api/billing-periods/{$period}", ['period_month' => '2026-11-01'])
                ->assertOk()
                ->assertJsonPath('data.label', 'Periode November')
                ->assertJsonPath('data.period_month', '2026-11-01');
            $this->patchJson("/api/billing-periods/{$period}", ['period_month' => '2026-11-15'])
                ->assertUnprocessable()->assertJsonValidationErrors(['period_month']);

            $this->postJson("/api/billing-periods/{$period}/close")->assertOk()
                ->assertJsonPath('data.label', 'Periode November');

            $this->getJson('/api/billing-periods/current')->assertOk()
                ->assertJsonPath('data.label', 'Periode Desember')
                ->assertJsonPath('data.period_month', '2026-12-01')
                ->assertJsonPath('data.sales_count', 0);

            $next = (int) $this->getJson('/api/billing-periods/current')->json('data.id');
            $this->patchJson("/api/billing-periods/{$period}", ['period_month' => '2026-12-01'])
                ->assertUnprocessable()->assertJsonValidationErrors(['status']);
            $this->postJson("/api/billing-periods/{$next}/cancel", ['reason' => 'Belum waktunya'])
                ->assertOk()->assertJsonPath('data.status', 'cancelled');
            $this->postJson('/api/billing-periods', [])->assertCreated()
                ->assertJsonPath('data.label', 'Periode Desember')
                ->assertJsonPath('data.period_month', '2026-12-01')
                ->assertJsonPath('data.sales_count', 0);
        } finally {
            Carbon::setTestNow();
        }
    }

    public function test_empty_open_or_closed_period_can_be_cancelled_with_reason(): void
    {
        $open = $this->openPeriod();
        $this->postJson("/api/billing-periods/{$open}/cancel", ['reason' => 'Dibuat tidak sengaja'])
            ->assertOk()->assertJsonPath('data.status', 'cancelled');
        $this->assertDatabaseHas('audit_logs', [
            'action' => 'billing_period.cancel',
            'entity_id' => $open,
            'actor_id' => $this->admin->id,
            'reason' => 'Dibuat tidak sengaja',
        ]);
        $this->getJson('/api/billing-periods/current')->assertOk()->assertJsonPath('data', null);
        $this->postJson("/api/billing-periods/{$open}/invoice")
            ->assertUnprocessable()->assertJsonValidationErrors(['status']);

        $closed = $this->openPeriod();
        $this->postJson("/api/billing-periods/{$closed}/close")->assertOk();
        $this->postJson("/api/billing-periods/{$closed}/cancel", ['reason' => 'Periode kosong tidak diperlukan'])
            ->assertOk()->assertJsonPath('data.status', 'cancelled');

        $this->postJson("/api/billing-periods/{$open}/cancel", ['reason' => 'Dibatalkan lagi'])
            ->assertUnprocessable()->assertJsonValidationErrors(['status']);
        $next = (int) $this->getJson('/api/billing-periods/current')->json('data.id');
        $this->postJson("/api/billing-periods/{$next}/cancel")
            ->assertUnprocessable()->assertJsonValidationErrors(['reason']);
    }

    public function test_period_with_credit_sales_cannot_be_cancelled_and_open_detail_counts_unbound_sales(): void
    {
        $employee = $this->employee('NIK-CANCEL', 'Karyawan Uji');
        $period = $this->openPeriod();
        $this->sale($employee, '25000.00');

        $this->getJson('/api/billing-periods/current')->assertOk()
            ->assertJsonPath('data.sales_count', 1)
            ->assertJsonPath('data.sales_total', '25000.00');
        $this->getJson("/api/billing-periods/{$period}")->assertOk()
            ->assertJsonPath('data.customers.0.name', 'Karyawan Uji');
        $this->postJson("/api/billing-periods/{$period}/cancel", ['reason' => 'Periode salah'])
            ->assertUnprocessable()->assertJsonValidationErrors(['status']);

        $this->postJson("/api/billing-periods/{$period}/close")->assertOk();
        $this->postJson("/api/billing-periods/{$period}/cancel", ['reason' => 'Periode salah'])
            ->assertUnprocessable()->assertJsonValidationErrors(['status']);

        $next = (int) $this->getJson('/api/billing-periods/current')->json('data.id');
        Sanctum::actingAs($this->cashier, ['*']);
        $this->postJson("/api/billing-periods/{$next}/cancel", ['reason' => 'Tidak berwenang'])->assertForbidden();
        $this->getJson('/api/billing-periods')->assertForbidden();
    }

    public function test_close_binds_credit_sales_and_opens_next_period(): void
    {
        $budi = $this->employee('NIK-1', 'Budi');
        $id = $this->openPeriod();
        $credit = $this->sale($budi, '100000.00');
        $cash = $this->sale(null, '50000.00', 'cash');

        $this->postJson("/api/billing-periods/{$id}/close")->assertOk()
            ->assertJsonPath('data.status', 'closed')->assertJsonPath('data.sales_count', 1)->assertJsonPath('data.sales_total', '100000.00')
            ->assertJsonPath('data.customers.0.name', 'Budi');

        $this->assertSame($id, (int) DB::table('sales')->where('id', $credit)->value('billing_period_id'));
        $this->assertNull(DB::table('sales')->where('id', $cash)->value('billing_period_id'));
        $this->assertDatabaseHas('audit_logs', ['action' => 'billing_period.close', 'entity_id' => $id, 'actor_id' => $this->admin->id]);

        $next = $this->getJson('/api/billing-periods/current')->assertOk()->json('data');
        $this->assertNotNull($next);
        $this->assertNotSame($id, $next['id']);
        $this->assertSame('open', $next['status']);

        // struk kredit setelah tutup tidak terikat ke periode lama
        $later = $this->sale($budi, '10000.00');
        $this->postJson("/api/billing-periods/{$next['id']}/close")->assertOk()->assertJsonPath('data.sales_count', 1);
        $this->assertNotSame($id, (int) DB::table('sales')->where('id', $later)->value('billing_period_id'));

        $this->postJson("/api/billing-periods/{$id}/close")->assertUnprocessable()->assertJsonValidationErrors(['status']);
        $this->patchJson("/api/billing-periods/{$id}", ['label' => 'x'])->assertUnprocessable();
    }

    public function test_closing_frees_the_credit_limit_of_the_new_period(): void
    {
        $budi = $this->employee('NIK-1', 'Budi');
        DB::table('customer_credit_limits')->insert(['customer_id' => $budi, 'limit_amount' => '500000.00', 'set_by' => $this->admin->id]);
        $id = $this->openPeriod();
        $this->sale($budi, '300000.00');

        $this->getJson("/api/customers/{$budi}")->assertJsonPath('data.credit_remaining', '200000.00');
        $this->postJson("/api/billing-periods/{$id}/close")->assertOk();
        $this->getJson("/api/customers/{$budi}")->assertJsonPath('data.credit_remaining', '500000.00');
    }

    public function test_generate_invoice_with_lines_grouped_per_employee(): void
    {
        [$period, $budi] = $this->closedPeriodWithSales();

        $r = $this->postJson("/api/billing-periods/{$period}/invoice", ['bill_to' => 'HRD PT Maju'])->assertCreated()
            ->assertJsonPath('data.status', 'draft')->assertJsonPath('data.bill_to', 'HRD PT Maju')
            ->assertJsonPath('data.subtotal', '175000.50')->assertJsonPath('data.tax_amount', '0.00')->assertJsonPath('data.tax_rate', null)
            ->assertJsonPath('data.total', '175000.50')->assertJsonPath('data.amount_remaining', '175000.50')
            ->assertJsonCount(2, 'data.customers')
            ->assertJsonPath('data.customers.0.name', 'Budi')->assertJsonPath('data.customers.0.subtotal', '150000.50')
            ->assertJsonCount(2, 'data.customers.0.sales')->assertJsonPath('data.customers.1.subtotal', '25000.00');

        $this->assertMatchesRegularExpression('/^INV-\d{6}-000001$/', $r->json('data.document_no'));
        $id = $r->json('data.id');

        $this->assertSame(3, DB::table('receivable_invoice_lines')->where('invoice_id', $id)->count());
        $this->assertSame(3, DB::table('sales')->where('invoice_id', $id)->where('billing_status', 'invoiced')->count());
        $this->assertSame('invoiced', DB::table('billing_periods')->where('id', $period)->value('status'));
        $this->assertDatabaseHas('audit_logs', ['action' => 'invoice.generate', 'entity_id' => $id]);

        $this->getJson("/api/billing-periods/{$period}")->assertJsonPath('data.invoice_id', $id);
        $this->getJson('/api/invoices')->assertOk()->assertJsonPath('total', 1);
        $this->getJson('/api/invoices?status=paid')->assertOk()->assertJsonPath('total', 0);
        $this->getJson('/api/invoices?status=bogus')->assertUnprocessable();

        // karyawan Budi memegang dua struk di invoice
        $this->assertSame(2, DB::table('receivable_invoice_lines')->where('invoice_id', $id)->where('customer_id', $budi)->count());
    }

    public function test_invoice_rules_open_period_duplicate_and_empty(): void
    {
        $open = $this->openPeriod();
        $this->postJson("/api/billing-periods/{$open}/invoice")->assertUnprocessable()->assertJsonValidationErrors(['status']);

        $this->postJson("/api/billing-periods/{$open}/close")->assertOk();   // kosong
        $this->postJson("/api/billing-periods/{$open}/invoice")->assertUnprocessable()->assertJsonValidationErrors(['status']);

        [$period] = $this->closedPeriodWithSalesInNextPeriod();
        $this->postJson("/api/billing-periods/{$period}/invoice")->assertCreated();
        $this->postJson("/api/billing-periods/{$period}/invoice")->assertUnprocessable()->assertJsonValidationErrors(['status']);
        $this->postJson('/api/billing-periods/99999/invoice')->assertNotFound();
    }

    /** Periode berikutnya (otomatis terbuka) diberi struk lalu ditutup. @return array{int} */
    private function closedPeriodWithSalesInNextPeriod(): array
    {
        $budi = $this->employee('NIK-9', 'Andi');
        $next = $this->getJson('/api/billing-periods/current')->json('data.id');
        $this->sale($budi, '40000.00');
        $this->postJson("/api/billing-periods/{$next}/close")->assertOk();

        return [$next];
    }

    public function test_invoice_aggregates_sale_time_vat_snapshots_without_recalculating(): void
    {
        [$period] = $this->closedPeriodWithSales();
        $sales = DB::table('sales')->where('billing_period_id', $period)->where('payment_mode', 'payroll_credit')->orderBy('id')->get();
        $snapshots = [
            ['subtotal' => '100000.00', 'tax_amount' => '11000.00', 'total' => '111000.00'],
            ['subtotal' => '50000.50', 'tax_amount' => '5500.06', 'total' => '55500.56'],
            ['subtotal' => '25000.00', 'tax_amount' => '2750.00', 'total' => '27750.00'],
        ];
        foreach ($sales as $index => $sale) {
            DB::table('sales')->where('id', $sale->id)->update($snapshots[$index] + ['tax_rate_snapshot' => '11.00']);
        }

        DB::table('settings')->insert(['store_id' => $this->storeId(), 'setting_key' => 'vat_enabled', 'setting_value' => json_encode(true)]);
        DB::table('tax_rates')->insert([
            'store_id' => $this->storeId(), 'name' => 'PPN tarif baru', 'rate' => '15.00', 'price_includes_tax' => 0,
            'effective_from' => now('Asia/Jakarta')->toDateString(), 'created_by' => $this->admin->id,
        ]);

        $this->postJson("/api/billing-periods/{$period}/invoice")->assertCreated()
            ->assertJsonPath('data.tax_rate', '11.00')->assertJsonPath('data.tax_amount', '19250.06')
            ->assertJsonPath('data.subtotal', '175000.50')->assertJsonPath('data.total', '194250.56')
            ->assertJsonPath('data.customers.0.subtotal', '150000.50');

        $this->assertSame(
            ['100000.00', '50000.50', '25000.00'],
            DB::table('receivable_invoice_lines')->where('invoice_id', DB::table('receivable_invoices')->value('id'))->orderBy('id')->pluck('amount')->all(),
        );
    }

    public function test_legacy_credit_sales_are_not_recalculated_with_current_vat(): void
    {
        [$period] = $this->closedPeriodWithSales();
        DB::table('settings')->insert(['store_id' => $this->storeId(), 'setting_key' => 'vat_enabled', 'setting_value' => json_encode(true)]);
        DB::table('tax_rates')->insert([
            'store_id' => $this->storeId(), 'name' => 'PPN terbaru', 'rate' => '15.00', 'price_includes_tax' => 0,
            'effective_from' => now('Asia/Jakarta')->toDateString(), 'created_by' => $this->admin->id,
        ]);

        $this->postJson("/api/billing-periods/{$period}/invoice")->assertCreated()
            ->assertJsonPath('data.tax_rate', null)->assertJsonPath('data.tax_amount', '0.00')
            ->assertJsonPath('data.subtotal', '175000.50')->assertJsonPath('data.total', '175000.50');
    }

    public function test_invoice_uses_inclusive_vat_snapshot_from_sale_time(): void
    {
        $budi = $this->employee('NIK-1', 'Budi');
        $id = $this->openPeriod();
        $saleId = $this->sale($budi, '111000.00');
        DB::table('sales')->where('id', $saleId)->update([
            'subtotal' => '100000.00', 'tax_rate_snapshot' => '11.00', 'tax_amount' => '11000.00',
        ]);
        $this->postJson("/api/billing-periods/{$id}/close")->assertOk();
        DB::table('settings')->insert(['store_id' => $this->storeId(), 'setting_key' => 'vat_enabled', 'setting_value' => json_encode(true)]);
        DB::table('tax_rates')->insert([
            'store_id' => $this->storeId(), 'name' => 'PPN terbaru', 'rate' => '15.00', 'price_includes_tax' => 0,
            'effective_from' => now('Asia/Jakarta')->toDateString(), 'created_by' => $this->admin->id,
        ]);

        $this->postJson("/api/billing-periods/{$id}/invoice")->assertCreated()
            ->assertJsonPath('data.subtotal', '100000.00')->assertJsonPath('data.tax_rate', '11.00')
            ->assertJsonPath('data.tax_amount', '11000.00')->assertJsonPath('data.total', '111000.00');
    }

    public function test_invoice_lifecycle_with_partial_payments(): void
    {
        [$period] = $this->closedPeriodWithSales();
        $invoice = $this->postJson("/api/billing-periods/{$period}/invoice")->assertCreated()->json('data.id');   // total 175000.50

        // belum diterbitkan: belum boleh dibayar
        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '1000'])->assertUnprocessable()->assertJsonValidationErrors(['status']);
        $this->postJson("/api/invoices/{$invoice}/hand-over")->assertUnprocessable()->assertJsonValidationErrors(['status']);

        $this->postJson("/api/invoices/{$invoice}/issue")->assertOk()->assertJsonPath('data.status', 'issued');
        $this->assertNotNull(DB::table('receivable_invoices')->where('id', $invoice)->value('issued_at'));
        $this->postJson("/api/invoices/{$invoice}/issue")->assertUnprocessable();
        $this->postJson("/api/invoices/{$invoice}/hand-over")->assertOk()->assertJsonPath('data.status', 'handed_to_hr');

        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '100000', 'reference' => 'TRF-1', 'received_on' => '2026-10-28'])
            ->assertCreated()->assertJsonPath('data.status', 'partially_paid')->assertJsonPath('data.amount_paid', '100000.00')
            ->assertJsonPath('data.amount_remaining', '75000.50')->assertJsonCount(1, 'data.payments');
        $paymentId = DB::table('invoice_payments')->where('invoice_id', $invoice)->value('id');
        $this->assertDatabaseHas('fund_ledger_entries', [
            'fund_account_id' => DB::table('fund_accounts')->where('store_id', $this->storeId())->where('type', 'main_cash')->value('id'),
            'entry_type' => 'invoice_payment_in',
            'amount' => '100000.00',
            'ref_type' => 'invoice_payment',
            'ref_id' => $paymentId,
        ]);
        $this->assertSame(3, DB::table('sales')->where('invoice_id', $invoice)->where('billing_status', 'invoiced')->count());

        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '75000.51'])->assertUnprocessable()->assertJsonValidationErrors(['amount']);
        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '0'])->assertUnprocessable();
        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '10.123'])->assertUnprocessable();

        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '75000.50'])->assertCreated()
            ->assertJsonPath('data.status', 'paid')->assertJsonPath('data.amount_remaining', '0.00')->assertJsonCount(2, 'data.payments');
        $this->assertSame(3, DB::table('sales')->where('invoice_id', $invoice)->where('billing_status', 'paid')->count());
        $this->assertDatabaseHas('audit_logs', ['action' => 'invoice.record_payment', 'entity_id' => $invoice, 'actor_id' => $this->admin->id]);

        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '1'])->assertUnprocessable()->assertJsonValidationErrors(['status']);
    }

    public function test_finance_can_verify_hrd_payment_and_payment_is_recorded_in_main_cash(): void
    {
        [$period] = $this->closedPeriodWithSales();
        $invoice = $this->postJson("/api/billing-periods/{$period}/invoice")->assertCreated()->json('data.id');
        $this->postJson("/api/invoices/{$invoice}/issue")->assertOk();
        $this->postJson("/api/invoices/{$invoice}/hand-over")->assertOk();

        $finance = $this->makeUser('Finance', 'finance-pembayaran-tagihan');
        Sanctum::actingAs($finance, ['*']);

        $this->postJson("/api/invoices/{$invoice}/payments", ['amount' => '50000', 'reference' => 'BANK-001'])
            ->assertCreated()
            ->assertJsonPath('data.status', 'partially_paid')
            ->assertJsonPath('data.amount_paid', '50000.00');

        $this->assertDatabaseHas('fund_ledger_entries', [
            'fund_account_id' => DB::table('fund_accounts')->where('store_id', $this->storeId())->where('type', 'main_cash')->value('id'),
            'entry_type' => 'invoice_payment_in',
            'amount' => '50000.00',
            'created_by' => $finance->id,
        ]);
    }

    public function test_cashier_and_guest_have_no_access(): void
    {
        $id = $this->openPeriod();
        Sanctum::actingAs($this->cashier, ['*']);
        app(PermissionResolver::class)->flush();

        $this->getJson('/api/billing-periods')->assertForbidden();
        $this->postJson('/api/billing-periods', [])->assertForbidden();
        $this->postJson("/api/billing-periods/{$id}/close")->assertForbidden();
        $this->postJson("/api/billing-periods/{$id}/invoice")->assertForbidden();
        $this->getJson('/api/invoices')->assertForbidden();
        $this->postJson('/api/invoices/1/payments', ['amount' => 1])->assertForbidden();
    }
}
