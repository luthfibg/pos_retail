<?php

use App\Exceptions\StockLockedByOpnameException;
use App\Http\Middleware\EnsurePlatformOperator;
use App\Http\Middleware\RequireAnyPermission;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'platform.operator' => EnsurePlatformOperator::class,
            'can.any' => RequireAnyPermission::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
        $exceptions->render(function (StockLockedByOpnameException $exception) {
            return response()->json([
                'message' => $exception->getMessage(),
                'code' => 'stock_locked_by_opname',
                'locked_products' => $exception->lockedProducts,
            ], 409);
        });
    })->create();
