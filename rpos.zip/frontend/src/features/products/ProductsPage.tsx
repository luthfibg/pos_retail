import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { categoryApi, inventoryApi, productApi } from '@/lib/api/endpoints';
import type { ProductStatus } from '@/lib/api/types';
import { formatQty, formatRupiah } from '@/lib/format';
import { useDebounce } from '@/hooks/useDebounce';
import { StockVelocityBadge } from '@/components/ui/StockVelocityBadge';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { ExpiryProductBadge } from '@/components/ui/ExpiryBadge';
import { useAuth } from '@/features/auth/AuthProvider';
import type { Product } from '@/lib/api/types';
import { ProductFormDialog } from './ProductFormDialog';
import { ProductStockDialog } from '@/features/inventory/ProductStockDialog';
import { sharedActiveSuppliers } from './productForm';

const STATUS_LABEL: Record<ProductStatus, string> = {
  active: 'Aktif',
  pending_price: 'Menunggu harga',
  inactive: 'Nonaktif',
};

export function ProductsPage() {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState<ProductStatus | ''>('');
  const [categoryId, setCategoryId] = useState<number | ''>('');
  const [page, setPage] = useState(1);
  const debouncedQ = useDebounce(q);
  const { can } = useAuth();
  const [dialog, setDialog] = useState<{ product?: Product } | null>(null);
  const canEdit = can('product.update');
  const canViewCost = can('inventory.adjust.approve');
  const canCreateReturn = can('supplier_return.create');
  const [selectedProducts, setSelectedProducts] = useState<Product[]>([]);
  const [stockOf, setStockOf] = useState<Product | null>(null);
  const navigate = useNavigate();

  const categories = useQuery({ queryKey: ['categories', 'all'], queryFn: () => categoryApi.list() });

  const products = useQuery({
    queryKey: ['products', { q: debouncedQ, status, categoryId, page }],
    queryFn: () =>
      productApi.list({
        q: debouncedQ || undefined,
        status: status || undefined,
        category_id: categoryId || undefined,
        page,
      }),
    placeholderData: keepPreviousData,
  });

  const rows = products.data?.data ?? [];
  const productIds = rows.map((product) => product.id);
  const expiryMonitoring = useQuery({
    queryKey: ['inventory', 'expiry-monitoring', 'products', productIds],
    queryFn: () => inventoryApi.expiryMonitoring(productIds),
    enabled: productIds.length > 0,
    staleTime: 5 * 60 * 1000,
  });
  const expiryStatusByProduct = new Map(
    (expiryMonitoring.data?.products ?? []).map((item) => [item.product_id, item.expiry_status]),
  );
  const fifoMonitoring = useQuery({
    queryKey: ['inventory', 'fifo-monitoring', productIds],
    queryFn: () => inventoryApi.fifoMonitoring(productIds),
    enabled: productIds.length > 0,
    staleTime: 5 * 60 * 1000,
    refetchInterval: 5 * 60 * 1000,
  });
  const fifoTypeByProduct = new Map(
    (fifoMonitoring.data?.products ?? []).map((item) => [item.product_id, item.fifo_type]),
  );
  const sharedSuppliers = sharedActiveSuppliers(selectedProducts);

  function canSelectForReturn(product: Product): boolean {
    if (!canCreateReturn || product.suppliers.every((supplier) => !supplier.is_active)) return false;
    if (selectedProducts.some((selected) => selected.id === product.id)) return true;
    return selectedProducts.length === 0
      || product.suppliers.some((supplier) => supplier.is_active && sharedSuppliers.some((shared) => shared.id === supplier.id));
  }

  return (
    <div className="space-y-4 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Data Stok</h1>
        {can('product.create') && (
          <button
            type="button"
            onClick={() => setDialog({})}
            className="rounded-md bg-slate-900 px-3 py-2 text-sm font-medium text-white"
          >
            Produk baru
          </button>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        <input
          className="w-64 rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
          placeholder="Cari nama, SKU, atau barcode"
          value={q}
          onChange={(e) => { setQ(e.target.value); setPage(1); }}
        />
        <select
          className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
          value={categoryId}
          onChange={(e) => { setCategoryId(e.target.value ? Number(e.target.value) : ''); setPage(1); }}
        >
          <option value="">Semua kategori</option>
          {categories.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select
          className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
          value={status}
          onChange={(e) => { setStatus(e.target.value as ProductStatus | ''); setPage(1); }}
        >
          <option value="">Semua status</option>
          {(Object.keys(STATUS_LABEL) as ProductStatus[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
        </select>
        {canCreateReturn && (
          <button
            type="button"
            disabled={selectedProducts.length === 0}
            onClick={() => navigate(`/supplier-returns?create=1&products=${selectedProducts.map((product) => product.id).join(',')}`)}
            className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm disabled:opacity-50"
          >
            Retur{selectedProducts.length > 0 ? ` (${selectedProducts.length})` : ''}
          </button>
        )}
      </div>

      <ErrorNotice error={products.error} />
      <ErrorNotice error={expiryMonitoring.error} />
      <ErrorNotice error={fifoMonitoring.error} />

      <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="w-10 px-3 py-2" />
              <th className="px-3 py-2">SKU</th>
              <th className="px-3 py-2">Nama</th>
              <th className="px-3 py-2">Kategori</th>
              <th className="px-3 py-2">Supplier</th>
              {canViewCost && <th className="px-3 py-2 text-right">Harga Modal Satuan</th>}
              <th className="px-3 py-2 text-right">Harga jual</th>
              <th className="px-3 py-2 text-right">Stok Gudang</th>
              <th className="px-3 py-2"> Kedaluwarsa</th>
              <th className="px-3 py-2 text-right">Barang masuk</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2">Kartu stok</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((p) => {
              const expiryStatus = expiryStatusByProduct.get(p.id);
              const fifoType = fifoTypeByProduct.get(p.id);
              return (
                <tr key={p.id}>
                  <td className="px-3 py-2">
                    <input
                      type="checkbox"
                      checked={selectedProducts.some((selected) => selected.id === p.id)}
                      disabled={!canSelectForReturn(p)}
                      onChange={(event) => {
                        setSelectedProducts((current) => event.target.checked
                          ? [...current, p]
                          : current.filter((selected) => selected.id !== p.id));
                      }}
                      title={!canSelectForReturn(p) ? 'Pilih produk yang memiliki supplier sama dengan pilihan saat ini.' : undefined}
                      aria-label={`Pilih ${p.name} untuk retur`}
                    />
                  </td>
                  <td className="px-3 py-2 font-mono text-xs">
                    {p.sku}
                    <div className="text-slate-400">{p.barcode}</div>
                  </td>
                  <td className="px-3 py-2">{p.name}</td>
                  <td className="px-3 py-2 text-slate-600">{p.category_name ?? '—'}</td>
                  <td className="px-3 py-2 text-slate-600">{p.suppliers.map((supplier) => supplier.name).join(', ') || '—'}</td>
                  {canViewCost && <td className="px-3 py-2 text-right tabular-nums">{formatRupiah(p.unit_cost)}</td>}
                  <td className="px-3 py-2 text-right tabular-nums">{formatRupiah(p.sell_price)}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{formatQty(p.stock_sellable)} {p.unit_name}</td>
                  <td className="px-3 py-2">
                    {expiryMonitoring.isPending ? <span className="text-xs text-slate-500">Memuat…</span>
                      : expiryMonitoring.isError ? <span className="text-xs text-red-700">Gagal dimuat</span>
                        : expiryStatus
                          ? <ExpiryProductBadge status={expiryStatus} />
                          : <span className="text-xs text-slate-500">Tidak tersedia</span>}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">{formatQty(p.restock_quantity)} {p.unit_name}</td>
                  <td className="px-3 py-2">
                    {fifoMonitoring.isPending ? <span className="text-xs text-slate-500">Memuat…</span>
                      : fifoMonitoring.isError ? <span className="text-xs text-red-700">Gagal dimuat</span>
                        : fifoType
                          ? <StockVelocityBadge type={fifoType} />
                          : <span className="text-xs text-slate-500">Tidak tersedia</span>}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-right">
                    <button type="button" onClick={() => setStockOf(p)} className="text-sm text-slate-700 underline">Stok</button>
                    {canEdit && (
                      <button type="button" onClick={() => setDialog({ product: p })} className="ml-3 text-sm text-slate-700 underline">Ubah</button>
                    )}
                  </td>
                </tr>
              );
            })}
            {!products.isLoading && rows.length === 0 && (
              <tr><td colSpan={canViewCost ? 12 : 11} className="px-3 py-8 text-center text-slate-500">Tidak ada produk.</td></tr>
            )}
            {products.isLoading && (
              <tr><td colSpan={canViewCost ? 12 : 11} className="px-3 py-8 text-center text-slate-500">Memuat…</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {products.data && products.data.last_page > 1 && (
        <div className="flex items-center justify-between text-sm">
          <span className="text-slate-500">
            {products.data.from}–{products.data.to} dari {products.data.total}
          </span>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
              className="rounded-md border border-slate-300 bg-white px-3 py-1.5 disabled:opacity-50"
            >
              Sebelumnya
            </button>
            <button
              type="button"
              disabled={page >= products.data.last_page}
              onClick={() => setPage((p) => p + 1)}
              className="rounded-md border border-slate-300 bg-white px-3 py-1.5 disabled:opacity-50"
            >
              Berikutnya
            </button>
          </div>
        </div>
      )}

      {stockOf && <ProductStockDialog product={stockOf} onClose={() => setStockOf(null)} />}
      {dialog && <ProductFormDialog product={dialog.product} onClose={() => setDialog(null)} />}
    </div>
  );
}
