import { useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { categoryApi, productApi, settingsApi, supplierApi } from '@/lib/api/endpoints';
import { ApiError } from '@/lib/api/client';
import type { Product, ProductStatus, Supplier } from '@/lib/api/types';
import { useAuth } from '@/features/auth/AuthProvider';
import { Modal } from '@/components/ui/Modal';
import { Field, inputCls } from '@/components/ui/Field';
import { LocalDecimalInput } from '@/components/ui/LocalDecimalInput';
import { ErrorNotice } from '@/components/ui/ErrorNotice';
import { formatQty, formatRupiah } from '@/lib/format';
import { calculateVatBreakdown } from '@/lib/money';
import {
  buildCreatePayload, buildUpdatePayload, emptyValues, normalizeDecimal, valuesFromProduct, validateProduct,
  normalizeScannedBarcode, type FormErrors, type ProductFormValues, type UpdatePayload,
} from './productForm';

type Job =
  | { kind: 'create'; input: ReturnType<typeof buildCreatePayload> }
  | { kind: 'update'; id: number; input: UpdatePayload };

const STATUS_LABEL: Record<ProductStatus, string> = {
  active: 'Aktif',
  pending_price: 'Menunggu harga',
  inactive: 'Nonaktif',
};

async function loadSuppliers(): Promise<Supplier[]> {
  const firstPage = await supplierApi.list({ per_page: 100 });
  if (firstPage.last_page === 1) return firstPage.data;

  const remainingPages = await Promise.all(
    Array.from({ length: firstPage.last_page - 1 }, (_, index) =>
      supplierApi.list({ per_page: 100, page: index + 2 }),
    ),
  );

  return [...firstPage.data, ...remainingPages.flatMap((page) => page.data)];
}

interface Props {
  /** undefined = produk baru */
  product?: Product;
  onClose: () => void;
}

export function ProductFormDialog({ product, onClose }: Props) {
  const mode = product ? 'edit' : 'create';
  const { can } = useAuth();
  const qc = useQueryClient();
  const caps = { canSetPrice: can('price.change'), canSetCost: can('price.change'), canActivate: can('product.activate') };
  const canViewVatSetting = caps.canSetPrice && can('settings.manage');

  const [values, setValues] = useState<ProductFormValues>(() => (product ? valuesFromProduct(product) : emptyValues()));
  const [errors, setErrors] = useState<FormErrors>({});
  const [created, setCreated] = useState<Product | null>(null);
  const [scannerValue, setScannerValue] = useState('');

  const vatSetting = useQuery({
    queryKey: ['settings', 'vat'],
    queryFn: settingsApi.vat,
    enabled: canViewVatSetting,
  });
  const categories = useQuery({ queryKey: ['categories', 'active'], queryFn: () => categoryApi.list(true) });
  const suppliers = useQuery({
    queryKey: ['suppliers', 'products'],
    queryFn: loadSuppliers,
  });
  const priceIncludesTax = vatSetting.data?.enabled === true && vatSetting.data.price_includes_tax === true;
  const showVatBreakdown = vatSetting.data?.enabled === true && vatSetting.data.price_includes_tax !== null;
  const vatBreakdown = showVatBreakdown && vatSetting.data?.rate !== null && vatSetting.data?.rate !== undefined
    ? calculateVatBreakdown(normalizeDecimal(values.sellPrice), vatSetting.data.rate, priceIncludesTax)
    : null;
  const vatRateLabel = vatSetting.data?.rate ? ` (${formatQty(vatSetting.data.rate)}%)` : '';

  const mutation = useMutation({
    mutationFn: (job: Job) =>
      job.kind === 'create' ? productApi.create(job.input) : productApi.update(job.id, job.input),
    onSuccess: (saved, job) => {
      void qc.invalidateQueries({ queryKey: ['products'] });
      void qc.invalidateQueries({ queryKey: ['categories'] });
      void qc.invalidateQueries({ queryKey: ['purchase-requisitions'] });
      if (job.kind === 'create') setCreated(saved);
      else onClose();
    },
  });

  const set = <K extends keyof ProductFormValues>(key: K, value: ProductFormValues[K]) =>
    setValues((v) => ({ ...v, [key]: value }));

  function applyScannerValue(value: string) {
    const barcode = normalizeScannedBarcode(value);
    if (!barcode) return;

    set('barcode', barcode);
    setScannerValue('');
    setErrors((current) => ({ ...current, barcode: undefined }));
    mutation.reset();
  }

  // Pesan dari server (422) per kolom, bila ada; kesalahan klien didahulukan.
  const serverErrors: FormErrors = {};
  if (mutation.error instanceof ApiError && mutation.error.status === 422) {
    for (const [k, msgs] of Object.entries(mutation.error.errors ?? {})) {
      const field = k.startsWith('supplier_ids.') ? 'supplier_ids' : k;
      (serverErrors as Record<string, string>)[field] = msgs[0] ?? '';
    }
  }
  const err = (k: keyof FormErrors) => errors[k] ?? serverErrors[k];
  const showTopError = !(mutation.error instanceof ApiError && mutation.error.status === 422);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (mutation.isPending) return; // cegah kirim ganda
    mutation.reset();

    const found = validateProduct(values, mode, caps, product);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    if (product) {
      const input = buildUpdatePayload(values, product, caps);
      if (Object.keys(input).length === 0) { onClose(); return; }
      mutation.mutate({ kind: 'update', id: product.id, input });
    } else {
      mutation.mutate({ kind: 'create', input: buildCreatePayload(values, caps) });
    }
  }

  function addAnother() {
    setCreated(null);
    setValues(emptyValues());
    setErrors({});
    mutation.reset();
  }

  if (created) {
    return (
      <Modal title="Produk dibuat" onClose={onClose}>
        <div className="space-y-3 p-5 text-sm">
          <p><span className="font-medium">{created.name}</span> berhasil disimpan.</p>
          <dl className="grid grid-cols-[6rem_1fr] gap-y-1 rounded-md bg-slate-50 p-3">
            <dt className="text-slate-500">SKU</dt><dd className="font-mono">{created.sku}</dd>
            <dt className="text-slate-500">Barcode</dt><dd className="font-mono">{created.barcode}</dd>
            <dt className="text-slate-500">Status</dt><dd>{STATUS_LABEL[created.status]}</dd>
          </dl>
          {created.status === 'pending_price' && (
            <p className="text-slate-600">Produk belum bisa dijual sampai Admin menetapkan harga dan mengaktifkannya.</p>
          )}
          <p className="text-slate-500">SKU dan barcode tidak dapat diubah setelah dibuat.</p>
        </div>
        <div className="flex justify-end gap-2 border-t border-slate-200 px-5 py-3">
          <button type="button" onClick={addAnother} className="rounded-md border border-slate-300 px-3 py-2 text-sm hover:bg-slate-50">Tambah lagi</button>
          <button type="button" onClick={onClose} className="rounded-md bg-slate-900 px-3 py-2 text-sm font-medium text-white">Selesai</button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title={product ? `Ubah produk — ${product.sku}` : 'Produk baru'} onClose={onClose}>
      <form onSubmit={onSubmit} noValidate>
        <div className="space-y-4 p-5">
          {showTopError && <ErrorNotice error={mutation.error} />}
          <ErrorNotice error={suppliers.error} />
          {canViewVatSetting && <ErrorNotice error={vatSetting.error} />}

          {mode === 'create' && (
            <Field label="Scan barcode">
              <input
                className={`${inputCls} min-h-11 font-mono`}
                value={scannerValue}
                placeholder="Scan barcode"
                autoFocus
                inputMode="none"
                onChange={(event) => setScannerValue(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter') {
                    event.preventDefault();
                    applyScannerValue(event.currentTarget.value);
                  }
                }}
              />
            </Field>
          )}

          <Field label="Nama produk" error={err('name')}>
            <input className={inputCls} value={values.name} onChange={(e) => set('name', e.target.value)} />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="SKU" error={err('sku')} hint={mode === 'create' ? 'Kosongkan untuk otomatis.' : 'Tidak dapat diubah.'}>
              <input
                className={`${inputCls} font-mono`}
                value={values.sku}
                placeholder={mode === 'create' ? 'Otomatis' : undefined}
                disabled={mode === 'edit'}
                onChange={(e) => set('sku', e.target.value)}
              />
            </Field>
            <Field label={mode === 'create' ? 'Barcode manual' : 'Barcode'} error={err('barcode')} hint={mode === 'create' ? 'Opsional; kosongkan untuk barcode otomatis.' : 'Tidak dapat diubah.'}>
              <input
                className={`${inputCls} font-mono`}
                value={values.barcode}
                placeholder={mode === 'create' ? 'Input manual' : undefined}
                disabled={mode === 'edit'}
                onChange={(e) => set('barcode', e.target.value)}
              />
            </Field>
          </div>

          <Field label="Supplier" error={err('supplier_ids')}>
            <div className="max-h-40 space-y-1 overflow-y-auto rounded-md border border-slate-300 p-2">
              {suppliers.data?.map((supplier) => {
                const selected = values.supplierIds.includes(supplier.id);
                return (
                  <label key={supplier.id} className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={selected}
                      disabled={suppliers.isLoading || (!supplier.is_active && !selected)}
                      onChange={(event) => set(
                        'supplierIds',
                        event.target.checked
                          ? [...values.supplierIds, supplier.id]
                          : values.supplierIds.filter((id) => id !== supplier.id),
                      )}
                    />
                    <span>{supplier.code} · {supplier.name}{supplier.is_active ? '' : ' (Nonaktif)'}</span>
                  </label>
                );
              })}
              {suppliers.data?.length === 0 && <p className="text-sm text-slate-500">Belum ada supplier.</p>}
            </div>
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Kategori" error={err('category_id')}>
              <select className={inputCls} value={values.categoryId} onChange={(e) => set('categoryId', e.target.value)}>
                <option value="">Tanpa kategori</option>
                {categories.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </Field>
            <Field label="Satuan" error={err('unit_name')}>
              <input className={inputCls} value={values.unitName} onChange={(e) => set('unitName', e.target.value)} />
            </Field>
          </div>

          {caps.canSetPrice ? (
            <>
              <Field
                label={priceIncludesTax ? 'Harga jual + PPN (Rp)' : 'Harga jual (Rp)'}
                error={err('sell_price')}
                hint={mode === 'create' ? 'Kosongkan bila harga belum ditetapkan.' : undefined}
              >
                <input
                  className={`${inputCls} tabular-nums`}
                  inputMode="decimal"
                  value={values.sellPrice}
                  onChange={(e) => set('sellPrice', e.target.value)}
                />
              </Field>
              {showVatBreakdown && (
                <div className="grid grid-cols-2 gap-3">
                  {priceIncludesTax ? (
                    <>
                      <ReadOnlyPriceField label="Harga jual (sebelum PPN)" value={vatBreakdown?.basePrice} />
                      <ReadOnlyPriceField label={`PPN termasuk${vatRateLabel}`} value={vatBreakdown?.taxAmount} />
                    </>
                  ) : (
                    <>
                      <ReadOnlyPriceField label={`PPN${vatRateLabel}`} value={vatBreakdown?.taxAmount} />
                      <ReadOnlyPriceField label="Harga jual + PPN" value={vatBreakdown?.totalPrice} />
                    </>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="rounded-md bg-slate-50 p-3 text-sm text-slate-600">
              {mode === 'create'
                ? 'Harga ditetapkan oleh Admin. Produk baru berstatus "Menunggu harga" dan belum bisa dijual.'
                : <>Harga jual: <span className="font-medium">{formatRupiah(product?.sell_price)}</span> (hanya Admin yang dapat mengubah).</>}
            </div>
          )}

          {(mode === 'create' || caps.canSetCost) && (
            <Field label="Harga Modal (Rp)" error={err('unit_cost')} hint="Harga Modal awal; setiap barang masuk dengan biaya akan menggantinya dengan biaya terbaru.">
              <LocalDecimalInput
                className={`${inputCls} tabular-nums`}
                kind="cost"
                value={values.unitCost}
                onChange={(value) => set('unitCost', value)}
              />
            </Field>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Field label="Batas minimum" error={err('min_stock')} hint="Status “Hampir habis” bila stok ≤ batas ini.">
              <LocalDecimalInput className={`${inputCls} tabular-nums`} kind="quantity" value={values.minStock} onChange={(value) => set('minStock', value)} />
            </Field>
            <Field label="Batas kritis" error={err('critical_stock')} hint="Status “Kritis” bila stok di bawah batas ini.">
              <LocalDecimalInput className={`${inputCls} tabular-nums`} kind="quantity" value={values.criticalStock} onChange={(value) => set('criticalStock', value)} />
            </Field>
          </div>

          <Field label="Jumlah isi ulang" error={err('restock_quantity')} hint="Jumlah unit yang diminta sistem saat stok mencapai ambang pemantauan. Isi 0 agar Permintaan otomatis tidak dibuat.">
            <LocalDecimalInput
              className={`${inputCls} tabular-nums`}
              kind="quantity"
              value={values.restockQuantity}
              onChange={(value) => set('restockQuantity', value)}
            />
          </Field>

          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={values.trackExpiry} onChange={(e) => set('trackExpiry', e.target.checked)} />
            Lacak tanggal kadaluarsa (penjualan memakai FEFO)
          </label>

          {mode === 'edit' && caps.canActivate && (
            <Field label="Status" error={err('status')} hint="Produk yang masih memiliki stok tidak dapat dinonaktifkan.">
              <select className={inputCls} value={values.status} onChange={(e) => set('status', e.target.value as ProductStatus)}>
                {product?.status === 'pending_price' && <option value="pending_price" disabled>{STATUS_LABEL.pending_price}</option>}
                <option value="active">{STATUS_LABEL.active}</option>
                <option value="inactive">{STATUS_LABEL.inactive}</option>
              </select>
            </Field>
          )}

          {mode === 'edit' && (
            <Field label="Alasan perubahan (opsional)" hint="Tercatat di audit log.">
              <input className={inputCls} value={values.reason} onChange={(e) => set('reason', e.target.value)} maxLength={500} />
            </Field>
          )}
        </div>

        <div className="flex justify-end gap-2 border-t border-slate-200 px-5 py-3">
          <button type="button" onClick={onClose} className="rounded-md border border-slate-300 px-3 py-2 text-sm hover:bg-slate-50">Batal</button>
          <button type="submit" disabled={mutation.isPending || suppliers.isLoading || suppliers.isError} className="rounded-md bg-slate-900 px-3 py-2 text-sm font-medium text-white disabled:opacity-60">
            {mutation.isPending ? 'Menyimpan…' : 'Simpan'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function ReadOnlyPriceField({ label, value }: { label: string; value?: string }) {
  return (
    <Field label={label}>
      <input
        className={`${inputCls} tabular-nums`}
        value={formatRupiah(value)}
        disabled
        readOnly
      />
    </Field>
  );
}
