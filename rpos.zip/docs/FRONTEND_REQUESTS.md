# Permintaan Frontend → Backend

**Berkas ini dibaca agent backend (B#2) di awal setiap sesi.** Agent frontend (F#2) menulis kebutuhan yang belum bisa dipenuhi kontrak API saat ini di sini, bukan mengubah kode backend. Satu entri per permintaan; jangan menghapus entri yang sudah selesai (ubah statusnya).

**Cara memakai (agent backend):**
1. Kerjakan permintaan berstatus `Diminta` sesuai prioritas. Bila ada bagian yang tidak masuk akal atau bertentangan dengan aturan bisnis, ubah status ke `Ditolak/Diskusi` dan tulis alasannya di bawah entri.
2. Setelah kode + test ditulis: ubah status ke `Ditulis (menunggu test)`; setelah pengguna menjalankan `php artisan test` dan hijau: `Selesai`.
3. Tambahkan kontraknya yang final di `BACKEND_PROGRESS.md` (bagian baru + Riwayat) dan perbarui `ROADMAP_PROGRESS.md`. Frontend hanya mempercayai `BACKEND_PROGRESS.md`.

| ID | Judul | Prioritas | Status | Diajukan |
|---|---|---|---|---|
| FR-01 | Pratinjau penjualan (`POST /api/sales/preview`) | Tinggi (layar kasir) | **Selesai backend** | 28 Okt 2026 |
| FR-02 | Izin Finance untuk daftar/detail setoran | Tinggi (antrean setoran) | **Selesai backend** | 28 Okt 2026 |
| FR-03 | Katalog lokasi dan posisi rak untuk transfer stok | Sedang (transfer/putaway) | **Diminta** | 27 Okt 2026 |
| FR-04 | Owner perlu melihat PO `pending_confirmation` pada daftar PO | Sedang (konfirmasi PO model standar) | **Ditulis (menunggu test)** | 1 Nov 2026 |

---

## FR-01 — Pratinjau penjualan

**Status:** Selesai backend · **Prioritas:** Tinggi · **Dibutuhkan oleh:** layar kasir `/pos` (frontend) · **Perubahan skema:** tidak ada (tanpa migration, tanpa permission baru).

### Masalah

Aturan proyek: harga, diskon, PPN, dan total **dihitung server** (HANDOFF; `BACKEND_PROGRESS.md` bagian 5), dan frontend tidak boleh menghitung ulang. Akibatnya, sebelum `POST /api/sales` Kasir tidak bisa mengetahui:

- **total sebenarnya** (diskon Admin terbaik per produk/kategori, PPN tunai maupun kredit bila `vat_enabled`) — padahal Kasir perlu angkanya untuk menyebut nominal dan menerima uang; uang diterima yang kurang baru ditolak setelah posting (`422 amount_tendered`)
- apakah **kredit akan melebihi batas** (`422 credit_limit`) — baru diketahui setelah menekan Bayar;
- apakah **stok cukup** (`422 items.N.qty`) — baru diketahui setelah menekan Bayar, sehingga antrean di kasir tertahan.

Menghitung sendiri di klien berarti menduplikasi aturan pembulatan, diskon terbaik, dan PPN, dan angkanya akan menyimpang dari struk. Karena itu diminta satu endpoint hanya-baca.

### Kontrak yang diusulkan

`POST /api/sales/preview` — `auth:sanctum`, `can:sales.create` (Kasir dan Admin). Dipanggil frontend setiap keranjang atau mode bayar berubah (didebounce ±300 ms), jadi harus murah: **tanpa transaksi tulis**, tanpa `lockForUpdate`.

Permintaan (aturan validasi **sama** dengan `StoreSaleRequest`, tanpa `idempotency_key`, `amount_tendered`, dan `credit_exception`):
```json
{ "payment_mode": "cash",
  "customer_id": null,
  "items": [ { "product_id": 12, "qty": "2" }, { "product_id": 15, "qty": "0.5" } ] }
```
- `payment_mode` wajib (`cash` | `payroll_credit`); frontend memanggil ulang saat mode berganti untuk memperbarui sinyal batas kredit.
- `customer_id` wajib bila `payroll_credit` (sama seperti posting).
- `items`: 1–100 baris; `qty` > 0, maks 99.999, maks 3 desimal.

Respons 200:
```json
{ "data": {
    "payment_mode": "cash",
    "lines": [
      { "index": 0, "product_id": 12, "sku": "P-000012", "name": "Air Mineral 600ml", "unit_name": "pcs",
        "qty": "2.000", "unit_price": "10000.00", "gross": "20000.00",
        "discount_amount": "0.00", "discount_name": null, "line_total": "20000.00",
        "stock_available": "24.000", "stock_sufficient": true }
    ],
    "subtotal": "27500.00", "discount_total": "0.00",
    "tax_rate": null, "tax_amount": "0.00", "total": "27500.00",
    "credit": null,
    "computed_at": "2026-10-25 03:10:00.000" } }
```
Untuk `payroll_credit`, `credit` berisi (selain itu `null`):
```json
"credit": { "customer_id": 3, "remaining_before": "900000.00", "remaining_after": "872500.00", "exceeds_limit": false }
```
Aturan isi:
- **`lines` = hasil penggabungan** produk yang sama (seperti posting). `index` = indeks baris pertama produk itu di permintaan, supaya kunci error sama dengan posting (`items.N.…`).
- Semua uang string desimal, bentuk dan pembulatan **persis** posting: `gross = round-half-up(unit_price × qty)`, diskon terbaik per baris (produk vs kategori), `tax_*` hanya untuk `cash`.
- `stock_available` = qty layak jual yang **bisa dijual FEFO** saat ini (batch kedaluwarsa tidak dihitung, sama dengan `InventoryService::sell`). `stock_sufficient` = `stock_available >= qty` gabungan. Hanya informasi; **tidak** menyebabkan 422.
- `credit.remaining_before/after` memakai rumus batas yang sama dengan `checkCreditLimit` (batas − struk kredit yang belum ditagih). **Jangan** mengirim nilai batas itu sendiri (Kasir tidak boleh melihatnya); `remaining_*` sudah boleh dilihat Kasir (`credit_remaining`). `exceeds_limit: true` bukan error: ini sinyal agar UI menawarkan tunai atau pengecualian Admin. `remaining_after` bernilai `"0.00"` bila melebihi (jangan negatif).

Kesalahan (422, kunci sama dengan posting agar pemeta error frontend dipakai ulang):

| Kunci | Kapan |
|---|---|
| `items.N.product_id` | produk tidak ada / bukan `active` / belum berharga |
| `items.N.qty`, `items`, `payment_mode` | validasi bentuk; `payment_mode` juga bila konfigurasi PPN belum lengkap (sama dengan posting) |
| `customer_id` | kredit tanpa debitur; debitur belum diverifikasi, nonaktif, atau batas belum diisi (sama dengan `assertCreditCustomer`) |

Tidak menjadi galat di pratinjau: stok kurang (→ `stock_sufficient: false`), melebihi batas kredit (→ `exceeds_limit: true`), shift belum dibuka / sedang `counting` (frontend memeriksanya lewat `GET /api/shifts/current`).

### Syarat implementasi

1. **Satu sumber logika harga.** Ekstrak langkah 3–4 `SaleService::postInTransaction` (penggabungan baris, pemuatan produk, diskon aktif, `gross`/diskon/`cashTax`) menjadi metode bersama yang dipakai posting **dan** pratinjau, agar angka keduanya tidak bisa menyimpang. Posting tetap memuat produk dengan `lockForUpdate`; pratinjau tanpa kunci.
2. **Murni hanya-baca:** tanpa baris `sales`/`sale_items`/`payments`, tanpa `NumberSequence::next` (nomor dokumen tidak boleh terbuang), tanpa mencatat idempotensi, tanpa ledger, tanpa `AuditLogger`.
3. **Rate limit** longgar per pengguna (usul `throttle:120,1`), karena dipanggil saat mengetik.
4. Bentuk respons ditambahkan ke `BACKEND_PROGRESS.md` bagian 5 (sub-bagian "Pratinjau").

### Test yang diharapkan (`SalePreviewTest`)

- Total pratinjau **sama persis** dengan total hasil `POST /api/sales` untuk data yang sama: tanpa diskon; dengan diskon produk dan kategori (diskon terbaik); `qty` desimal; PPN tunai dan kredit eksklusif maupun inklusif.
- Tidak ada baris baru di `sales`, `sale_items`, `payments`, `fund_ledger_entries`, `audit_logs`, dan `number_sequences` tidak berubah setelah pratinjau.
- Produk yang sama di dua baris digabung; `lines[].index` = indeks baris pertama.
- Stok kurang → 200 dengan `stock_sufficient: false`; batch kedaluwarsa tidak dihitung di `stock_available`.
- Kredit: `remaining_before/after` benar dan memperhitungkan struk kredit yang belum ditagih; melebihi batas → `exceeds_limit: true`, `remaining_after: "0.00"`, nilai batas tidak ada di respons.
- 422 untuk produk `pending_price`/`inactive`, debitur yang belum memiliki batas atau sudah diarsipkan, kredit tanpa `customer_id`.
- 401 untuk tamu; 403 untuk pengguna tanpa `sales.create`.

### Di luar cakupan (sengaja tidak diminta)

- Reservasi stok atau penguncian harga antara pratinjau dan posting: posting tetap menghitung ulang dan otoritatif. Frontend akan membandingkan `total` posting dengan pratinjau dan memberi tahu Kasir bila berbeda (mis. Admin mengubah harga di tengah transaksi).
- Hitungan kembalian: frontend hanya mengurangkan `amount_tendered − total` untuk tampilan (bilangan bulat sen, tanpa float); nilai resmi tetap `payment.change_given` dari respons posting.
- Menyimpan keranjang tertahan (hold).

### Catatan untuk agent backend

Bila lebih mudah, nama rute boleh diubah (mis. `POST /api/sales/quote`); kabari lewat bagian "Diskusi" di bawah dan frontend menyesuaikan.

**Diskusi / keputusan:** _(kosong)_

---

## FR-02 — Izin Finance untuk daftar/detail setoran

**Status:** Selesai backend · **Prioritas:** Tinggi · **Dibutuhkan oleh:** halaman `/cash-deposits` · **Perubahan skema:** tidak ada.

`GET /api/cash-deposits` dan `GET /api/cash-deposits/{id}` menerima salah satu permission `cash_deposit.create` atau `cash_deposit.receive`. Pemegang `create` tetap terbatas pada shift sendiri; pemegang `receive` dapat melihat semua setoran. Izin untuk membuat/menyerahkan setoran tetap terpisah dari izin Finance untuk menerima/mengoreksi dan membaca saldo dana.

`CashDepositTest` menguji akses Finance dengan `cash_deposit.receive` saja untuk daftar, detail lintas shift, penerimaan, koreksi, dan saldo; juga memastikan Finance tidak dapat membuat/menyerahkan setoran dan pengguna tanpa kedua izin ditolak.

---

## FR-03 — Katalog lokasi dan posisi rak untuk transfer stok

**Status:** Diminta · **Prioritas:** Sedang · **Dibutuhkan oleh:** `/inventory/transfers` · **Perubahan skema:** tidak ada.

UI transfer membutuhkan daftar lokasi aktif yang boleh dipakai sebagai asal/tujuan dan daftar posisi rak aktif untuk lokasi tujuan. Kontrak yang ada hanya menyediakan `GET /api/goods-receipts/receiving-locations`, yang mensyaratkan `goods_receipt.create`, sedangkan transfer memakai `stock_transfer.create`. Endpoint itu juga tidak menyediakan posisi rak, sehingga UI transfer saat ini memakai ID posisi tujuan opsional (tidak praktis untuk putaway).

Mohon sediakan endpoint baca dengan izin `stock_transfer.create`, misalnya `GET /api/inventory/transfer-options`, yang mengembalikan:

```json
{
  "data": {
    "locations": [
      { "id": 1, "type": "store_floor", "name": "Area Toko" }
    ],
    "positions": [
      { "id": 3, "location_id": 1, "shelf_id": 2, "shelf_code": "A1", "shelf_name": "Rak A", "level": 1, "slot": 2 }
    ]
  }
}
```

Hanya sertakan lokasi aktif pada toko pengguna. Bila `warehouse_enabled=false`, gudang tidak disertakan; posisi hanya dari rak/posisi aktif pada lokasi yang disertakan. Pastikan pengguna dengan `stock_transfer.create` saja dapat mengakses endpoint ini tanpa `goods_receipt.create`; tambahkan test otorisasi dan penyaringan lokasi/rak nonaktif.

---

## FR-04 — Owner perlu melihat PO `pending_confirmation` pada daftar PO

**Status:** Ditulis (menunggu test) · **Prioritas:** Sedang · **Dibutuhkan oleh:** papan `/purchase-requisitions` tab "PO Diproses" · **Perubahan skema:** tidak ada.

### Masalah
`PurchaseOrderService::search` hanya mengembalikan semua status bila pengguna memegang `purchase_order.create`; selain itu daftar dipaksa ke `approved, sent, partially_received` (`RECEIVABLE`). Pada model standar retail, Owner memegang `purchase_requisition.approve` (yang dipakai `POST /api/purchase-orders/{id}/confirm`) tetapi tidak memegang `purchase_order.create`. Akibatnya PO berstatus `pending_confirmation` tidak muncul di daftar Owner, sehingga Owner tidak punya jalan di UI untuk menemukan PO yang harus ia konfirmasi. `find()` sudah memperlakukan `purchase_requisition.approve` sebagai pengelola (detail PO dapat dibuka), jadi hanya daftar yang tertinggal.

### Permintaan
Samakan `$manager` pada `search()` dengan `$canManage` pada `find()` (`purchase_order.create` atau `purchase_order.send` atau `purchase_requisition.approve`). Opsional: `seesPrices` juga mencakup `purchase_requisition.approve`, karena Owner mengonfirmasi PO tanpa melihat total/harga saat ini. Tambahkan test otorisasi untuk Owner pada model standar.

**Diskusi / keputusan:** Dikerjakan backend (2 Nov 2026): `PurchaseOrderService::search` memakai syarat yang sama dengan `find` (`purchase_order.create`, `purchase_order.send`, atau `purchase_requisition.approve`), dan harga/total ikut tampil bagi pemegang `purchase_requisition.approve`. Test: `StockAuthorityTest::test_owner_sees_pending_confirmation_purchase_orders_with_prices`. Kontrak di `BACKEND_PROGRESS.md` bagian 13.
